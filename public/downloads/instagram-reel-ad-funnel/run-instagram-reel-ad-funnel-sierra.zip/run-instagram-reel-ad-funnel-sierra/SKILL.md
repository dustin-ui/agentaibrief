---
name: run-instagram-reel-ad-funnel-sierra
description: "Create, review, and publish a generic two-stage Meta Ads funnel for an existing Instagram Reel, including a Sierra Interactive property tracking link configured for full forced registration: an Engagement campaign optimized for video views, a viewer custom audience, and an optional Leads retargeting campaign. Use when an agent is asked to launch, draft, repeat, or recreate an Instagram Reel ad funnel with Sierra Interactive forced-registration tracking."
---

# Run Instagram Reel Ad Funnel with Sierra

Use Computer Use with the operator's signed-in browser sessions for Meta Ads Manager and Sierra Interactive. Target visible control names, roles, and current values; never replay coordinates or hardcode account, campaign, ad-set, ad, post, form, audience, agent, or website IDs. Follow the intent below when either service changes labels.

## Establish scope and inputs

Support four linked deliverables:

1. Sierra Interactive forced-registration tracking link
2. Instagram Reel video-view campaign
3. Video-viewer custom audience
4. Optional retargeting lead campaign

Perform only the requested deliverables. Do not create the retargeting campaign until its custom audience is selectable.

Require or safely infer:

- Meta business and ad account
- Facebook Page and Instagram professional profile
- Campaign names
- Existing Instagram Reel, identified by caption phrase or posting date
- Budget type, amount, start, end, and time zone for each campaign
- Whether a Special Ad Category applies
- Location target and radius
- Viewer threshold and audience-retention period
- Exact Sierra Interactive property-detail page
- Sierra tracking-link name, source, campaign, lender-routing choice, agent-routing choice, lead owner, and action plan
- Retargeting conversion location, form, CTA, and tracking settings

Always treat the Sierra values as inputs. Never substitute a person, brokerage, domain, campaign, routing rule, or action plan from a prior run.

Treat `draft` or `set up` as authorization to save drafts only. Treat `run`, `launch`, or `publish` with complete inputs as authorization to publish the requested campaigns. If authorization is unclear, stop at final review.

## Preflight

1. Verify the intended Meta business and ad account. Stop if signed out or ambiguous.
2. Verify the intended Sierra Interactive account and site. Stop if signed out or ambiguous.
3. Confirm that the requested Reel is published and selectable from the intended Instagram profile.
4. Open the exact Sierra property-detail page and verify the address or listing identifier.
5. Record the exact budgets, schedules, time zone, audience rule, retention period, location, identities, Reel, Sierra routing choices, form, and requested scope.
6. Make no substitutions for missing inputs.

## Create the Sierra forced-registration link

1. From the exact property-detail page, open Sierra Interactive's tracking-link generator.
2. Enter the operator-supplied tracking-link name, normally a property name or address.
3. Set registration to **Full Registration** so the destination uses forced registration. Do not choose normal registration.
4. Set Source to **Instagram** unless the operator supplied another source.
5. Select or create the exact operator-supplied campaign. Avoid duplicate campaigns with near-identical names.
6. Set the lender-routing choice exactly as supplied.
7. Set the agent-routing choice and lead owner exactly as supplied.
8. Select the exact action plan supplied by the operator.
9. Review every setting, select **Build Tracking Link**, and copy the generated URL.
10. Open the URL in a separate tab and verify that it resolves to the intended property and presents the expected full-registration behavior. Do not submit a test lead unless explicitly authorized.
11. Keep the verified generated URL as the destination for the Meta ads. Check clipboard contents before pasting.

## Create the Reel video-view campaign

1. Go to Meta **Campaigns**, select **Create**, choose **Engagement**, and continue with manual setup.
2. At campaign level:
   - Enter the exact campaign name.
   - Keep buying type **Auction** and objective **Engagement**.
   - Keep A/B testing off unless requested.
   - Select the applicable Special Ad Category. Do not omit a required category to regain targeting options.
3. At ad-set level:
   - Set conversion location to **On your ad**.
   - Set engagement type to **Video views**.
   - Set performance goal to **Maximize 2-second continuous video plays**, unless another available video-view goal was requested.
   - Enter and verify the exact budget and schedule.
   - Configure the requested location and radius.
   - Configure placements as requested. For an Instagram-only setup, turn off Facebook, Audience Network, Messenger, WhatsApp, and Threads; keep the requested Instagram Feed, Stories, and Reels placements; turn off any excluded Instagram placements.
   - Turn **Allow limited spending to excluded placements** off when strict placement exclusions are requested.
4. At ad level:
   - Select the exact Facebook Page and Instagram profile.
   - Turn **Multi-advertiser ads** off unless requested.
   - Choose **Use existing post**, open **Select post**, switch to **Instagram**, and match the Reel by profile, caption, media type, and date. Never rely on list position.
   - Set the requested CTA.
   - Paste the verified Sierra forced-registration URL into the destination field.
   - Configure Website Events, Offline Events, and URL parameters only when explicitly requested and fully specified.
5. Review campaign name, objective, category, optimization, budget, schedule, location, placements, identities, Reel, CTA, Sierra URL, and tracking.
6. Save a draft or publish according to authorization. After publishing, verify Meta reports one campaign, one ad set, and one ad; report any policy or delivery error verbatim.

## Create the Reel-viewer audience

1. Open **Audiences**, choose **Create audience** > **Custom audience** > **Video**.
2. Select the exact viewer threshold. Use **People who have viewed at least 3 seconds** only when the operator accepts that rule.
3. Select videos, set Video Source to **Instagram professional account**, choose the intended profile, and filter by **Campaign**.
4. Search the exact campaign name and select the matching Reel. Verify Selected Videos contains exactly the intended media.
5. Enter and verify the requested retention period; never silently accept Meta's default.
6. Enter the exact audience name, create it, and verify its source, rule, retention, and availability.

## Create the retargeting lead campaign

1. Return to **Campaigns**, select **Create**, choose **Leads**, and continue with manual setup.
2. At campaign level:
   - Enter the exact campaign name, budget type, and amount.
   - Select the applicable Special Ad Category.
3. At ad-set level:
   - Set the requested conversion location, such as **Website and instant forms**.
   - Enter and verify the requested schedule and geographic limits.
   - Select the newly created Reel-viewer custom audience.
   - Disable or stop for review if Advantage+ expansion would materially broaden a strict retargeting audience.
4. At ad level:
   - Select the exact Page and Instagram profile.
   - Choose **Use existing post** and select the intended Reel by profile, caption, media type, and date.
   - Select an approved existing form or create a new instant form from operator-supplied content. Review every generated field, disclosure, privacy-policy link, and completion screen before saving.
   - Set the requested CTA and paste the verified Sierra forced-registration URL.
   - Configure events and URL parameters only when explicitly requested.
5. Review the campaign, audience, form, CTA, Sierra destination, and tracking. Save a draft or publish according to authorization.
6. After publishing, verify Meta reports one campaign, one ad set, and one ad.

## Guardrails and completion report

- Never guess a budget, schedule, retention period, identity, Reel, audience, Sierra routing value, lead owner, action plan, form answer, privacy-policy URL, or destination.
- Never submit a test lead, message a lead, or change Sierra routing rules without explicit authorization.
- Never publish a duplicate after a slow or ambiguous response; inspect names and delivery state first.
- Never expose account IDs, email addresses, cookies, generated lead data, or private session details.
- Preserve drafts and report the last verified level if interrupted.

Return a concise summary containing statuses, campaign names, budgets, schedules, identities, selected Reel, audience rule and retention, location, placements, Sierra source/campaign/routing choices, destination domain, form, CTA, and any unresolved warning. Do not repeat sensitive URLs containing private query parameters; report only the destination domain unless the operator asks for the full link.
