---
name: run-instagram-reel-ad-funnel
description: "Create, review, and publish a generic two-stage Meta Ads funnel for an existing Instagram Reel: an Engagement campaign optimized for video views, a custom audience of Reel viewers, and an optional Leads retargeting campaign with an instant form. Use when an agent is asked to run, launch, draft, repeat, or recreate an Instagram Reel video-view campaign or Reel-viewer retargeting funnel without Sierra Interactive tracking or forced registration."
---

# Run Instagram Reel Ad Funnel

Use Computer Use with the operator's signed-in browser session. Target visible control names, roles, and current values; never replay coordinates or hardcode account, campaign, ad-set, ad, post, form, or audience IDs. Follow the intent below when Meta changes labels.

## Establish scope and inputs

Support three linked deliverables:

1. Instagram Reel video-view campaign
2. Video-viewer custom audience
3. Optional retargeting lead campaign

Perform only the requested deliverables. Do not create the retargeting campaign until its custom audience is selectable.

Require or safely infer:

- Meta business and ad account
- Facebook Page and Instagram professional profile
- Campaign names
- Existing Instagram Reel, identified by caption phrase or posting date
- Budget type, amount, start, end, and time zone for each campaign
- Whether a Special Ad Category applies
- Location target and radius
- Viewer threshold and audience-retention period
- Final landing-page URL supplied by the operator
- Retargeting conversion location, form, CTA, and tracking settings

Never open Sierra Interactive, generate a Sierra tracking link, or enable forced registration. Use the supplied landing-page URL exactly after verifying its destination.

Treat `draft` or `set up` as authorization to save drafts only. Treat `run`, `launch`, or `publish` with complete inputs as authorization to publish the requested campaigns. If authorization is unclear, stop at final review.

## Preflight

1. Verify the intended Meta business and ad account. Stop if signed out or ambiguous.
2. Confirm that the requested Reel is published and selectable from the intended Instagram profile.
3. Open the supplied landing-page URL and verify that it resolves to the intended destination without an unexpected login, forced-registration gate, or redirect.
4. Record the exact budgets, schedules, time zone, audience rule, retention period, location, identities, Reel, URL, form, and requested scope.
5. Make no substitutions for missing inputs.

## Create the Reel video-view campaign

1. Go to **Campaigns**, select **Create**, choose **Engagement**, and continue with manual setup.
2. At campaign level:
   - Enter the exact campaign name.
   - Keep buying type **Auction** and objective **Engagement**.
   - Keep A/B testing off unless requested.
   - Select the applicable Special Ad Category. Do not omit a required category to regain targeting options.
3. At ad-set level:
   - Set conversion location to **On your ad**.
   - Set engagement type to **Video views**.
   - Set performance goal to **Maximize 2-second continuous video plays**, unless the operator requests another available video-view goal.
   - Enter and verify the exact budget and schedule.
   - Configure the requested location and radius.
   - Configure placements as requested. For an Instagram-only setup, turn off Facebook, Audience Network, Messenger, WhatsApp, and Threads; keep the requested Instagram Feed, Stories, and Reels placements; turn off any excluded Instagram placements.
   - Turn **Allow limited spending to excluded placements** off when strict placement exclusions are requested.
4. At ad level:
   - Select the exact Facebook Page and Instagram profile.
   - Turn **Multi-advertiser ads** off unless requested.
   - Choose **Use existing post**, open **Select post**, switch to **Instagram**, and match the Reel by profile, caption, media type, and date. Never rely on list position.
   - Set the requested CTA.
   - Enter the supplied landing-page URL.
   - Configure Website Events, Offline Events, and URL parameters only when explicitly requested and fully specified.
5. Review campaign name, objective, category, optimization, budget, schedule, location, placements, identities, Reel, CTA, URL, and tracking.
6. Save a draft or publish according to authorization. After publishing, verify Meta reports one campaign, one ad set, and one ad; report any policy or delivery error verbatim.

## Create the Reel-viewer audience

1. Open **Audiences**, choose **Create audience** > **Custom audience** > **Video**.
2. Select the exact viewer threshold. Use **People who have viewed at least 3 seconds** only when the operator accepts that rule.
3. Select videos, set Video Source to **Instagram professional account**, choose the intended profile, and filter by **Campaign**.
4. Search the exact campaign name and select the matching Reel. Verify Selected Videos contains exactly the intended media.
5. Enter and verify the requested retention period; never silently accept Meta's default.
6. Enter the exact audience name, create it, and verify its source, rule, retention, and availability.

## Create the retargeting lead campaign

1. Return to **Campaigns**, select **Create**, choose **Leads**, and continue with manual setup.
2. At campaign level:
   - Enter the exact campaign name, budget type, and amount.
   - Select the applicable Special Ad Category.
3. At ad-set level:
   - Set the requested conversion location, such as **Website and instant forms**.
   - Enter and verify the requested schedule.
   - Configure the requested geographic limits.
   - Select the newly created Reel-viewer custom audience.
   - Disable or stop for review if Advantage+ expansion would materially broaden a strict retargeting audience.
4. At ad level:
   - Select the exact Page and Instagram profile.
   - Choose **Use existing post** and select the intended Reel by profile, caption, media type, and date.
   - Select an approved existing form or create a new instant form from operator-supplied content. Review every generated field, disclosure, privacy-policy link, and completion screen before saving.
   - Set the requested CTA and supplied landing-page URL.
   - Configure events and URL parameters only when explicitly requested.
5. Review the campaign, audience, form, CTA, destination, and tracking. Save a draft or publish according to authorization.
6. After publishing, verify Meta reports one campaign, one ad set, and one ad.

## Guardrails and completion report

- Never guess a budget, schedule, retention period, identity, Reel, audience, form answer, privacy-policy URL, or destination.
- Never publish a duplicate after a slow or ambiguous response; inspect names and delivery state first.
- Never expose account IDs, email addresses, cookies, or private session details.
- Preserve drafts and report the last verified level if interrupted.

Return a concise summary containing statuses, campaign names, budgets, schedules, identities, selected Reel, audience rule and retention, location, placements, form, CTA, destination domain, and any unresolved warning.
