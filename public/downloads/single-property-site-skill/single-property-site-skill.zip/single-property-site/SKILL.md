---
name: single-property-site
description: Build a complete, deploy-ready single property website (listing microsite) for a residential listing from a folder or Google Drive link of listing photos. Use this whenever an agent asks to create a property website, listing website, microsite, landing page, or "site for my new listing," or mentions an address plus photos and wants a web presence for it — even if they don't say the word "website." Interviews the agent for listing facts and branding, LOOKS at every photo to classify the room and level, orders the gallery in buyer walkthrough order (exterior → main level → upper level → basement → outdoor), and generates a fast single-page site plus an unbranded MLS-compliant mirror. Also use this when the agent mentions running ads to a listing, wanting a squeeze page / forced-registration / landing page for a property, capturing buyer leads from a listing site, or buying a domain for a listing — Ad Mode adds a registration gate with Continue-with-Google, a leads backend the agent can view, and a cheap-domain purchase walkthrough with automatic URL swap.
---

# Single Property Site

Turn a folder of listing photos into a property website that looks like it was art-directed for that one house — not squeezed into a lead-gen template. One page, no framework, no build step, deployable anywhere in minutes.

**What makes this different from template tools:** the page serves the property, not the vendor. No pop-ups, no "free home value" interruptions, no carousel of other listings. One property, one story, one clear way to reach the agent. The photo order is decided by actually looking at the photos, and the palette is sampled from the house itself. When the agent is running paid traffic, **Ad Mode** adds the one interruption allowed to exist — a registration gate with Continue-with-Google and a leads backend — and keeps even that off the MLS mirror.

## Design philosophy (read before building)

The most attractive sites use a few effects thoughtfully. This skill deliberately uses **only** these, and nothing else:

1. **Motion hero** — full-bleed best exterior photo with a slow 12s Ken Burns zoom (or a muted looping video if the agent provides one), address and price overlaid.
2. **Scroll-triggered reveals** — sections fade and rise 24px as they enter the viewport. Once, subtly, never on the gallery grid itself.
3. **Animated stats** — beds / baths / sqft / acreage count up when scrolled into view.
4. **Lightbox gallery** — keyboard arrows, swipe, room-name captions, preloads neighbors.
5. **Sticky navigation** — transparent over the hero, solid after scroll. On mobile, a fixed bottom action bar: **Call · Text · Tour**. This bar is where the leads come from; it is always visible.
6. **Subtle hover states** — gallery images scale 1.03 with a room label; buttons lift 2px.
7. **Foundations** — generous whitespace, strong type hierarchy, a consistent palette, a polished compliance footer.
8. **Performance + accessibility** — lazy loading, responsive `srcset`, `prefers-reduced-motion` honored everywhere, alt text on every image.

**Deliberately rejected** (do not add these even if you're tempted): parallax, custom cursors, 3D elements, interactive backgrounds, loading screens, animated typography, dark/light mode toggles, autoplaying audio. Restraint is the luxury signal.

**The two signature elements** (the things this page is remembered by):
- **The Tour Rail** — because photos are ordered as a walkthrough, the gallery is grouped under level headers (*Main Level · Upper Level · Lower Level · Outdoor Living*). On desktop, a slim fixed rail highlights which level the visitor is currently scrolling through. On mobile the level headers are sticky.
- **The house-number monogram** — the street number set large in the display serif, used in the hero, as section dividers, and as the favicon.

## Non-negotiables

- **Never invent property facts.** Every number, feature, and claim comes from the agent or the config. If unknown, ask or omit. Never guess sqft, year built, or renovation dates.
- **Fair Housing copy rules.** Describe the property and objective location facts. Never describe ideal buyers or residents, never use demographic language, never characterize neighborhood "safety" or resident makeup, never rate school quality in agent-authored copy (naming the school district as a fact is fine if the agent supplies it).
- **Approval gates.** Do not write any site code until the agent approves the photo order and build plan (Step 4). Do not deploy anywhere without explicit approval.
- **STOP file.** If a file named `STOP` exists in the working directory or the skill directory, halt immediately and tell the agent why you stopped.
- **Nationally neutral.** No region-specific assumptions. MLS rules vary; ask rather than assume.

## Step 0 — State check

1. Check for `STOP` file. If present, halt.
2. Check for `~/.agent-skills/agent-profile.json`. If it exists, load it and skip the Batch B interview questions below — just confirm: "Building this as {name}, {brokerage} — still right?"
3. Check the current directory for `listing-config.json`. If present, this is an **edit session** — skip to the Edit sessions section at the bottom.

## Step 1 — Interview

Ask in two short batches. Accept partial answers; only re-ask what's missing. Keep it conversational — this is a busy agent on their phone.

**Batch A — the listing:**
- Property address (street, city, state, ZIP)
- Price (or "Coming Soon" / "Call for price")
- Beds, full baths, half baths, finished sqft, lot size, year built
- Photos: **Google Drive folder link** or a local folder path
- Listing description: paste it, or say "draft it" and I'll write one from the facts + photos (draft requires approval before it goes on the page; Fair Housing rules above apply)
- 5–8 headline features/upgrades (roof year, kitchen reno, ADU, no HOA, etc.)
- Matterport / 3D tour URL, video tour URL, floor plan file (all optional)
- Open house dates/times (optional)
- Property status (Coming Soon / For Sale / Under Contract)
- Purchased domain for this property, if any (e.g., 123MapleSt.com) — if none, the domain offer comes at deploy time (Step 8)
- Running paid ads to this page? If yes, **Ad Mode**: gate everyone or **ad clicks only** (auto-detects `fbclid`/`gclid`/UTM arrivals, so organic, sign, and MLS traffic stays ungated), and gate style — **soft** (recommended: free hero + stats + first 8 photos, register to unlock the rest and the tour) or **hard** (full-screen squeeze page before any content), and **Google-first with a form fallback** or **Google-only** (verified leads only)

**Batch B — the agent (first run only; saved to profile):**
- Name, title, team name, brokerage name + office address
- Phone, email, website
- License number(s) and state(s)
- Headshot (file path or Drive link) and team/brokerage logo file
- Brand colors, if any (otherwise the palette is sampled from the property photos — recommended)
- Are you a REALTOR® (NAR member)? (controls whether the REALTOR® mark appears)
- Lead capture preference: (a) Call/Text buttons only, (b) Formspree/Basin form endpoint, (c) custom webhook URL, (d) mailto form fallback
- Leads backend for Ad Mode registrations: (a) **Google Sheet** via Apps Script — the default; the Sheet is the registrant dashboard, and it can auto-forward each lead to a CRM lead-inbox email; (b) **Netlify Forms** if deploying there — dashboard built in; (c) **Cloudflare D1** with a generated `/leads` admin page behind an access key
- If using Continue with Google: a Google OAuth Client ID (walk them through creating one at console.cloud.google.com — about five minutes; the plain form works without it)
- Required MLS disclaimer wording, if your MLS mandates specific text
- Generate an unbranded MLS-compliant mirror page? (default: yes)

Save Batch B answers to `~/.agent-skills/agent-profile.json`. Save Batch A answers to `./listing-config.json` (schema in Appendix A) and keep it updated through every later step.

## Step 2 — Get the photos

Create the working structure:

```
{address-slug}/
  listing-config.json
  photos-src/          # originals, untouched
  site/
    index.html
    unbranded.html
    photos/full/  photos/thumb/
    agent/
```

**Google Drive link:** `pip install gdown` then `gdown --folder "<link>" -O photos-src --remaining-ok`. If the folder has permission issues or >50 files and gdown chokes, tell the agent plainly: "Drive is blocking the bulk download — easiest fix is to download the folder as a zip and give me the path." Never silently proceed with a partial set; report the count downloaded vs. expected if known.

**Local path:** copy (don't move) into `photos-src/`.

Also fetch the headshot and any logo files into `site/agent/`. Report the final inventory: "Got 47 photos, headshot, and your logo."

## Step 3 — Look at every photo: classify and order

This is the heart of the skill. **Open and visually inspect every image.** Filenames from photographers are hints at best and wrong often enough to embarrass you — verify with your eyes.

For each photo, record: `file`, `room`, `level`, `orientation`, `quality note`, `action (keep/cut/unsure)`.

**Classification taxonomy and target order (buyer walkthrough order):**

| # | Group | Contains |
|---|-------|----------|
| 1 | Exterior — front | Front elevation, curb, twilight shots |
| 2 | Entry | Foyer, entryway, staircase (one stair shot max) |
| 3 | Main level — living | Living room, family room, great room |
| 4 | Main level — dining | Dining room, breakfast nook |
| 5 | Main level — kitchen | Kitchen, island, pantry, butler's pantry |
| 6 | Main level — other | Office/den, powder room, mudroom, main-level laundry |
| 7 | Upper level — primary suite | Primary bedroom, then primary bath, then closet |
| 8 | Upper level — secondary | Each secondary bedroom, then hall baths, loft, upstairs laundry |
| 9 | Lower level | Rec room first, then bar/gym/guest suite/bonus; cut bare utility rooms unless notable |
| 10 | Garage / outbuildings | Garage, barn, ADU, workshop |
| 11 | Outdoor living | Deck, patio, porch, pool, hot tub, outdoor kitchen |
| 12 | Yard & land | Lawn, gardens, pond, acreage, trails |
| 13 | Aerial | Drone shots, lot-line overlays |
| 14 | Community | Neighborhood amenities (only if agent supplied them) |
| 15 | Floor plans | Always last |

**Visual cues for the hard calls:**
- *Basement vs. main level:* smaller or high-set windows, walkout sliders, drop ceilings or exposed ductwork, carpet over concrete, mechanical equipment visible, lower ceiling height.
- *Primary vs. secondary bedroom:* room size, king staging, tray ceilings, visible ensuite or double-door entry, walk-in closet adjacency.
- *Which bath goes with which bedroom:* match finishes and flooring to the adjacent bedroom photos.
- *Same room, multiple angles:* keep 2–3 best angles of hero rooms (kitchen, great room, primary), 1–2 of everything else.

**Additional rules:**
- **Hero selection:** the single best horizontal front exterior — twilight beats daytime if both exist and the twilight shot is sharp. The hero also seeds the 1200×630 social share image.
- **Near-duplicates:** keep the better exposure/composition; move the loser to the cut list.
- **Flag for cutting:** blurry, dark, distorted verticals, toilet-lid-up bathroom shots, empty closets, bare utility rooms.
- **Unsure?** Mark it `unsure` and let the agent settle it in the approval table. Never bluff a room label.
- Target 35–60 kept photos for most listings. More acreage/outbuildings justifies more.

Rename kept photos in final order: `NNN-level-room.jpg` (e.g., `001-exterior-front.jpg`, `014-upper-primary-bedroom.jpg`).

## Step 4 — Approval gate (hard stop)

Present, and then **wait for explicit approval**:

1. **Photo plan** — a markdown table: `# | file | room | level | keep/cut/unsure | note`, plus the proposed hero and the cut list with one-line reasons.
2. **Design direction** — pick one of the three directions below based on the photo set, and say why. Show the sampled palette (see Design directions).
3. **Page outline** — the section list for this specific listing (skip sections with no content; never render empty placeholders).
4. **Draft description**, if the agent asked you to write one.

If the agent says "swap 12 and 14" or "cut the garage shots," update `listing-config.json` and re-present only what changed. Build nothing until you get a clear yes.

## Step 5 — Optimize images

Work from `photos-src/`, never overwrite originals. Prefer ImageMagick (`magick`); on macOS without it, fall back to `sips`.

- **Full size:** longest edge 2000px, quality 82, strip metadata (`-strip` — this also removes GPS EXIF, which you always want gone from a public listing): `magick in.jpg -auto-orient -resize '2000x2000>' -quality 82 -strip site/photos/full/NNN-level-room.jpg`
- **Thumbs:** same, at 800px, into `photos/thumb/`.
- **Hero preload copy** at 1600px for fast first paint.
- **Social image:** center-crop the hero to exactly 1200×630 → `site/social.jpg`.
- **Headshot:** 480px square-ish crop, `site/agent/headshot.jpg`.
- **Favicon:** generate an SVG favicon of the house-number monogram in the display serif on the accent color.

## Step 6 — Build the site

One self-contained `index.html`: inline CSS and vanilla JS (target < 15KB of JS, zero libraries), Google Fonts (2 families max, `preconnect`, `display=swap`, system-font fallbacks).

### Page structure (skip any section with no content)

1. **Hero** — full-bleed hero photo (Ken Burns) or muted looping video. Overlay: status eyebrow (COMING SOON / FOR SALE), street address as the headline in the display serif, city/state/price below, two buttons: *Schedule a Showing* and *Take the 3D Tour* (if provided). Scroll cue at the bottom.
2. **Sticky nav** — anchors: Gallery · Details · Tour · Location · Contact, plus the agent's phone number on desktop. Mobile gets the fixed bottom bar instead: **Call** (`tel:`), **Text** (`sms:` prefilled with "Hi, I'm interested in {address}"), **Tour** (scrolls to contact/scheduling).
3. **Stats band** — beds · baths · finished sqft · lot size · year built, counting up on first view.
4. **Narrative** — the listing description as real typography: display-serif opening line, comfortable measure (~65ch), generous leading. Not a wall of text — break into 2–4 paragraphs.
5. **Feature highlights** — the 5–8 headline features as a clean two-column list (single column on mobile). No icon clip-art.
6. **Gallery (the Tour Rail)** — grouped under level headers in walkthrough order. Responsive grid (3-up desktop, 2-up tablet, 1–2 mobile), thumbs lazy-loaded, click opens the lightbox at that photo. Desktop shows the fixed level rail; mobile makes level headers sticky.
7. **3D tour / video** — Matterport or video embed, lazy-loaded iframe with a poster frame, only if provided.
8. **Floor plans** — if provided.
9. **Location** — embedded map (OpenStreetMap iframe by default; Google Maps embed if the agent has a key) + a short factual location paragraph from agent-supplied points only.
10. **Open house** — dates/times as a simple card, only if provided.
11. **Agent card** — headshot, name, title, team, brokerage, license #(s), phone (`tel:`), email, website. This is the only agent promo on the page. No reviews, no other listings, no seller-guide bait.
12. **Contact / lead capture** — per the profile preference. Forms post to Formspree/webhook; mailto fallback opens a prefilled email. Simple fields: name, phone, email, message. No gating, no multi-step qualifiers.
13. **Compliance footer** — see below.
14. **Registration gate (Ad Mode only)** — an overlay inside `index.html`, not a separate page. See the Ad Mode section.

### Design directions

Pick one per listing; the agent confirms at the gate. **In all three, the accent color is sampled from the property photos** — the front door, the brick, the barn red, the pool blue, the landscape green. Pull 2–3 candidate hexes while classifying photos and show them at the approval gate. This is why no two sites from this skill look alike. If the agent insists on brand colors, map their primary to the accent role instead.

- **Estate** (default for traditional/luxury/acreage): warm ivory background `#F6F3EC`, ink text `#1C1A17`, property-sampled accent, display serif **Cormorant Garamond** + body **Inter**. Editorial print-ad feel, hairline rules, small-caps eyebrows.
- **Gallery** (modern builds, condos, minimalist staging): white `#FFFFFF`, near-black `#141414`, property-sampled accent used sparingly, display **Fraunces** (opsz high, restrained) + body **Inter**. Museum-plaque captions, extra whitespace, photos dominate.
- **Dusk** (twilight-heavy shoots, dramatic luxury): charcoal `#121316`, warm white text `#F2EFE9`, sampled warm-metallic accent, display **Cormorant Garamond** + body **Inter**. Translucent glass nav over the hero. Verify contrast ratios on every text/background pair.

Typography rules for all three: display serif only for the address, prices, section headers, and the monogram; everything else in the body face. Real hierarchy through size and space, not bolding everything.

### Effects implementation notes

- **Ken Burns:** CSS `transform: scale(1.0 → 1.08)` over 12s ease-out on the hero image only.
- **Reveals:** one `IntersectionObserver` (threshold 0.15) adds an `.in` class; CSS transitions opacity/translateY(24px→0) over 700ms; children stagger via `transition-delay`; fire once.
- **Count-ups:** on intersect, animate over ~1.2s with ease-out, comma-formatted.
- **Lightbox:** `<dialog>`-based, arrows/Escape/swipe, caption = room label, preload previous/next.
- **`prefers-reduced-motion: reduce`:** hero is static, reveals render instantly, counters show final values. Non-negotiable.
- **Performance:** hero `<img>` gets `fetchpriority="high"` + preload; everything below the fold `loading="lazy" decoding="async"`; every image gets `width`/`height` (no layout shift) and `srcset` (thumb/full); descriptive alt text from the room labels ("Kitchen with center island, main level").

### Compliance footer (both pages)

- Brokerage name + office address; agent name + license #(s) and state(s) *(branded page only)*.
- **Equal Housing Opportunity logo** — inline SVG (Appendix B) + the words "Equal Housing Opportunity."
- **REALTOR® wordmark** — only if the profile confirms NAR membership. Render as styled text small-caps with the ® — do not redraw the block-R logo. If the agent supplies their official REALTOR® or board logo file, place that image instead.
- MLS source + "Information deemed reliable but not guaranteed," plus any MLS-mandated wording from the profile.
- No tracking pixels or third-party scripts unless the agent explicitly asks.

### Unbranded MLS mirror (`unbranded.html`)

Many MLSs prohibit branded links in listing fields. Generate a mirror that is the same site **minus**: agent card, contact section, all Call/Text/Tour CTAs and the mobile action bar, brokerage/team names and logos, headshot, and agent metadata in the page head. Keep: photos, stats, description, features, tour, floor plans, map, EHO logo, and the disclaimer line. Nothing on the branded page links to it; give the agent the URL path to paste into their MLS field.

### Ad Mode: registration gate + leads backend

Build this only when the agent opted in. The gate lives inside `index.html`, controlled by `listing-config.json → ads.gate`:

- **`ads_only`** (recommended default): the gate arms itself only for visitors arriving with `fbclid`, `gclid`, or any `utm_*` parameter — i.e., paid clicks. Sign scans, MLS traffic, and organic visitors browse free. Zero URL management: the agent points the ad at the plain site URL and detection is automatic.
- **`soft`** (everyone): hero, stats band, and first `ads.free_photos` gallery thumbs are free; the remaining grid blurs behind an overlay — "Unlock all {N} photos + the 3D tour."
- **`hard`** (everyone): full-screen squeeze page before any content — dimmed hero behind, address, price, one factual hook line, registration card. Classic ad landing page.
- Successful registration sets `localStorage.spw_registered`; that device is never gated again.

**Registration card, in this order:** a **Continue with Google** button (Google Identity Services using the profile's client ID; decode the returned credential client-side for verified name + email — one tap on mobile, no fake addresses), then a plain fallback form (name, email, phone — keep phone optional; requiring it kills ad conversion). Skip Facebook Login: it requires creating a Facebook app plus review approval for the email permission, and Google + the form covers everyone.

**On submit, POST to the backend:** `{name, email, phone, method: "google"|"form", utm_source, utm_medium, utm_campaign, ad_click: "fbclid"|"gclid"|"none", listing_address, timestamp}`. The UTM fields are what tell the agent which ad produced which lead. Then unblur and set localStorage.

**Google-only mode** (`ads.method: "google_only"`): the hard gate can require Google sign-in with no form at all — every lead arrives with a verified name and email, zero fakes. Two things make it work in the real world:
1. **Meta's in-app browser blocks Google OAuth.** Most Facebook/Instagram ad clicks open in the in-app webview, where Google disallows sign-in. So even in google_only mode, detect the in-app browser (user agent contains `FBAN`, `FBAV`, or `Instagram`) and fall back to the plain form there — or show an "open in your browser ↗" prompt. Never ship a Google-only gate without testing it from an actual Instagram ad click on a phone.
2. **Authorized origins are per-domain, not per-path.** The button silently won't render unless the site's domain is listed in the OAuth client's Authorized JavaScript origins. One origin covers unlimited listings if they live at paths on one domain (`listings.agentsite.com/123-maple-st`) — another reason the Step 8 subdomain model pays off. Per-listing vanity domains each need adding (30 seconds; remind the agent at every deploy). Publishing the consent screen with only basic profile scopes requires no Google review.

**Backend implementations (one, per profile choice):**
- **Google Sheet (default):** generate `apps-script/Code.gs` — a `doPost` that appends a row, plus optional `MailApp.sendEmail` so every registration is also emailed to the agent's CRM lead-inbox address (most CRMs ingest leads from a parsing address). Walkthrough: create a Sheet → Extensions → Apps Script → paste → Deploy → Web app → access "Anyone" → copy the URL into the profile. Columns: timestamp, name, email, phone, method, source, medium, campaign, ad click, listing. The Sheet **is** the registrant dashboard — sortable, shareable, exportable.
- **Netlify Forms:** add `data-netlify` attributes to the fallback form and POST the Google-button result to the same endpoint; submissions appear in the Netlify dashboard with email notifications. Only if deploying on Netlify.
- **Cloudflare D1:** generate `functions/api/register.js` (insert) and `functions/leads.js` — a minimal admin page at `/leads?key={ACCESS_KEY}` listing registrants newest-first with UTM columns and a CSV export link. Set `ACCESS_KEY` as an environment variable at deploy; never hardcode it.

**Gate rules that protect the agent:** never gate `unbranded.html` — MLS rules prohibit forced registration on the link that goes in the MLS field. Never let the soft gate block the compliance footer or the Call/Text bar; an unregistered visitor who wants to phone the agent should always be able to. And always test the full register → backend-row → ungated flow before handoff.

### Head, social, and schema

- `<title>`: "{Address} — {City}, {ST}". Meta description: one factual, compelling line (Fair Housing rules apply).
- Open Graph + Twitter card: `og:title` = the address, `og:image` = `social.jpg`, `og:description` = the hook line. This is what makes the link unfurl beautifully in texts and posts — never ship a listing site with junk OG tags.
- JSON-LD: `RealEstateListing` with `SingleFamilyResidence` (address, floorSize, numberOfRooms), `Offer` (price, availability), and `RealEstateAgent` (branded page only).
- Canonical URL if a domain was provided.

## Step 7 — QA (run before showing the agent)

- Render/check at 390px, 768px, and 1440px. The mobile bottom bar must never cover content at page end (add bottom padding).
- Click every photo → correct lightbox position and caption. Arrow keys and swipe work.
- `tel:` and `sms:` links dial/prefill correctly with the profile phone.
- Form posts (or mailto opens prefilled) correctly.
- Toggle `prefers-reduced-motion` and confirm the static experience.
- Confirm order on page matches the approved table exactly; every image has alt text and dimensions.
- Confirm no invented facts: cross-check every number on the page against `listing-config.json`.
- Open `unbranded.html` and hunt for any leaked agent identity — name, phone, logo, headshot, email, metadata.
- **Ad Mode only:** visit with `?fbclid=test` → gate appears; without params in `ads_only` mode → it doesn't. Register through the form → a row lands in the backend with the UTM fields → page unblurs → reload stays ungated. Confirm `unbranded.html` never gates and the Call/Text bar stays reachable under a soft gate.

## Step 8 — Preview and handoff

1. `python3 -m http.server 8080` from `site/` and give the agent the local URL for both pages.
2. After approval, offer deploy options (act only on explicit instruction): **Netlify Drop** (drag the `site/` folder — fastest; required if the backend is Netlify Forms), **Cloudflare Pages** (required if the backend is D1), or **Vercel**/their existing host. The platform hands back a temporary URL like `{something}.netlify.app` — treat it as scaffolding, not the address the agent markets.
3. **Custom domain offer (ask on every listing without one):** "Want `{Number}{Street}.com` for this? GoDaddy renewals run roughly double these:" — **Cloudflare Registrar** (at-cost wholesale pricing, ~$10–11/yr for a .com, no renewal markup; the natural pick when deploying on Cloudflare Pages) or **Porkbun** (~$11/yr, free WHOIS privacy). Suggest 2–3 name candidates built from the address and hand over pre-filled search links: `https://porkbun.com/checkout/search?q={domain}` and `https://www.namecheap.com/domains/registration/results/?domain={domain}` (Cloudflare requires logging in first: dash.cloudflare.com → Domain Registration). Then ask directly: **"Did you purchase it?"**
4. **If they bought it — swap the URL everywhere.** Connect the domain in the deploy platform's custom-domain settings and walk through the DNS records it asks for. Set `listing-config.json → domain`, then sweep the temporary platform URL out of everything it touched: `<link rel="canonical">`, `og:url`, JSON-LD `url`, the sms prefill if it includes a link, and any QR code. Re-deploy, verify HTTPS resolves on the custom domain, and remind the agent to put the custom domain in ad destination URLs and to update the unbranded link in the MLS if it changed.
5. **SEO note worth sharing:** standalone property domains lose their earned authority when the listing sells. If the agent has a main website, suggest hosting at a subdomain or path of it (e.g., `listings.theiragentsite.com/123-maple-st`) so the traffic and backlinks compound on their own domain — the vanity domain can 301-redirect there for yard signs and ads.
6. Remind them: originals are untouched in `photos-src/`; the site folder is fully portable, and the leads backend keeps working wherever the site is hosted.

## Edit sessions

If `listing-config.json` exists, don't re-interview. Ask what changed (price drop, status → Under Contract, new twilight photos, open house added), update the config, regenerate only the affected parts of both pages, and re-run the relevant QA lines. Status changes update the hero eyebrow, JSON-LD availability, and OG description.

## Appendix A — config schemas

`~/.agent-skills/agent-profile.json`:
```json
{
  "name": "", "title": "", "team": "", "brokerage": "", "office_address": "",
  "phone": "", "email": "", "website": "",
  "licenses": [{"state": "", "number": ""}],
  "headshot": "path", "logo": "path",
  "brand_colors": {"primary": "", "use_sampled_palette": true},
  "nar_member": true,
  "lead_capture": {"mode": "call_text|formspree|webhook|mailto", "endpoint": ""},
  "lead_backend": {"mode": "sheet|netlify|d1", "endpoint": "", "google_client_id": "", "crm_lead_email": "", "admin_key_env": "ACCESS_KEY"},
  "mls_disclaimer": "", "unbranded_mirror": true
}
```

`./listing-config.json`:
```json
{
  "address": {"street": "", "city": "", "state": "", "zip": ""},
  "status": "coming_soon|for_sale|under_contract",
  "price": 0, "beds": 0, "baths_full": 0, "baths_half": 0,
  "sqft": 0, "lot": "", "year_built": 0,
  "description": "", "features": [],
  "tour_url": "", "video_url": "", "floorplans": [],
  "open_houses": [{"date": "", "start": "", "end": ""}],
  "domain": "",
  "ads": {"gate": "off|soft|hard|ads_only", "method": "google_first|google_only", "free_photos": 8},
  "design_direction": "estate|gallery|dusk",
  "palette": {"accent": "", "sampled_from": ""},
  "hero": "photos/full/001-exterior-front.jpg",
  "photo_order": [{"file": "", "room": "", "level": "main|upper|lower|out", "caption": ""}],
  "cut_list": [{"file": "", "reason": ""}]
}
```

## Appendix B — Equal Housing Opportunity inline SVG

Use this compact mark in the footer (official EPS available from HUD if the agent wants to swap it in):

```html
<svg viewBox="0 0 60 60" width="34" height="34" role="img" aria-label="Equal Housing Opportunity">
  <path fill="currentColor" d="M30 2 3 24h7v32h40V24h7L30 2Zm14 48H16V21.8L30 10.4l14 11.4V50Z"/>
  <rect fill="currentColor" x="20" y="27" width="20" height="5"/>
  <rect fill="currentColor" x="20" y="37" width="20" height="5"/>
</svg>
```
