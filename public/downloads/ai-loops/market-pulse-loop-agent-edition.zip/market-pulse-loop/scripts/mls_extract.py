#!/usr/bin/env python3
"""mls_extract.py — pulls per-city MLS exports using the user's OWN
logged-in session in a persistent Chromium profile.

SETUP (once, interactive — see references/extraction-mls.md):
  playwright codegen --user-data-dir=~/.market-loop-profile https://<your-mls-portal>
Record: login (2FA once) -> Residential Sold search, close date last 730 days,
one city, Export CSV -> Residential Active search, same city, Export CSV.
Paste the recorded steps into run_city() below and parameterize the city.

Usage:
  python mls_extract.py --cities springfield "lakeside" --headless
Reads city display names from market-loop/cities.json (slug -> mls_area).
"""
import argparse, json, random, sys, time
from pathlib import Path

PROFILE = Path.home() / ".market-loop-profile"
RAW = Path("market-loop/data/raw")
PACING_SECONDS = (20, 45)  # polite, human-scale; do not remove

def run_city(page, city_query: str, slug: str, run_date: str):
    """RECORDED CLICKPATH GOES HERE.
    Replace the body with your parameterized playwright-codegen recording.
    Must end with two downloads saved as:
      RAW/<slug>/solds_730d_<run_date>.csv
      RAW/<slug>/actives_<run_date>.csv
    """
    raise NotImplementedError(
        "Paste your recorded MLS clickpath into run_city() first — "
        "see references/extraction-mls.md, 'First-time setup'."
    )
    # --- RECORDED CLICKPATH (example shape) ---
    # page.goto("https://.../search")
    # page.get_by_label("Status").select_option("Closed")
    # page.get_by_label("Close Date").fill(...)          # last 730 days
    # page.get_by_placeholder("City").fill(city_query)
    # with page.expect_download() as dl:
    #     page.get_by_role("button", name="Export").click()
    # dl.value.save_as(RAW / slug / f"solds_730d_{run_date}.csv")
    # ... repeat for Active snapshot ...

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cities", nargs="+", required=True, help="slugs from cities.json")
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--run-date", default=time.strftime("%Y-%m-%d"))
    a = ap.parse_args()

    from playwright.sync_api import sync_playwright  # import late: nicer error if missing
    cities = {c["slug"]: c for c in json.load(open("market-loop/cities.json"))["cities"]}

    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(str(PROFILE), headless=a.headless)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        ok, failed = [], []
        for slug in a.cities:
            c = cities.get(slug)
            if not c:
                failed.append((slug, "not in cities.json")); continue
            (RAW / slug).mkdir(parents=True, exist_ok=True)
            try:
                run_city(page, c.get("mls_area", c["name"]), slug, a.run_date)
                ok.append(slug)
            except NotImplementedError as e:
                sys.exit(str(e))
            except Exception as e:
                shot = Path("market-loop/data/errors"); shot.mkdir(parents=True, exist_ok=True)
                page.screenshot(path=str(shot / f"{slug}_{a.run_date}.png"))
                failed.append((slug, f"{type(e).__name__}: {e}"))
            time.sleep(random.uniform(*PACING_SECONDS))
        ctx.close()

    print(json.dumps({"ok": ok, "failed": failed}, indent=2))
    if failed:
        print("\nFallback: drop manual exports into market-loop/data/inbox/ as "
              "<slug>_solds.csv and <slug>_actives.csv, then rerun the loop.")

if __name__ == "__main__":
    main()
