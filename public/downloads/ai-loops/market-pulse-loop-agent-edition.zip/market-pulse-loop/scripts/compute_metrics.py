#!/usr/bin/env python3
"""compute_metrics.py — Market Pulse Loop metric engine.

Usage:
  python compute_metrics.py --slug yourcity --solds path/to/solds_730d.csv \
      --actives path/to/actives.csv [--run-date YYYY-MM-DD] [--column-map market-loop/column_map.json]

Reads a 730-day closed-sales export + an actives snapshot, computes TTM vs
prior-TTM vs 90-day-pulse metrics per references/metrics-spec.md, and writes
market-loop/data/metrics/<slug>_<date>.json. Pages may cite ONLY this JSON.
"""
import argparse, csv, json, os, statistics, sys
from datetime import datetime, timedelta

DEFAULT_MAP = {
    "close_date":  ["close date", "closing date", "settled date", "sold date", "closedate"],
    "close_price": ["close price", "sold price", "sale price", "closeprice"],
    "list_price":  ["list price", "current price", "listprice", "original list price"],
    "dom":         ["dom", "days on market", "cdom", "adom"],
    "sqft":        ["interior sqft", "total finished sqft", "living area", "sqft total", "above grade finished sqft", "sqft"],
    "list_date":   ["list date", "listing date", "listdate"],
}

def norm(s): return "".join(c for c in s.lower().strip() if c.isalnum() or c == " ")

def build_map(headers, user_map):
    m, headers_n = {}, {norm(h): h for h in headers}
    merged = {k: [norm(a) for a in v] for k, v in DEFAULT_MAP.items()}
    for k, aliases in (user_map or {}).items():
        merged.setdefault(k, []).extend(norm(a) for a in aliases) if isinstance(aliases, list) else merged.setdefault(k, []).insert(0, norm(aliases))
    for field, aliases in merged.items():
        for a in aliases:
            if a in headers_n:
                m[field] = headers_n[a]; break
    return m

def parse_date(v):
    v = (v or "").strip()
    for f in ("%m/%d/%Y", "%Y-%m-%d", "%m/%d/%y", "%m-%d-%Y", "%b %d, %Y"):
        try: return datetime.strptime(v, f)
        except ValueError: pass
    return None

def parse_num(v):
    try: return float(str(v).replace("$", "").replace(",", "").strip())
    except (ValueError, AttributeError): return None

def med(xs): return statistics.median(xs) if xs else None
def pct_delta(new, old):
    if new is None or old in (None, 0): return None
    return round((new - old) / old * 100, 1)

def load_solds(path, user_map):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if not rows: sys.exit(f"No rows in {path}")
    cmap = build_map(rows[0].keys(), user_map)
    missing = [k for k in ("close_date", "close_price", "list_price", "dom") if k not in cmap]
    if missing:
        sys.exit(f"Unmapped required columns {missing}. Headers seen: {list(rows[0].keys())}\n"
                 f"Add aliases to market-loop/column_map.json and rerun.")
    out, dropped, seen = [], 0, set()
    for r in rows:
        d = parse_date(r.get(cmap["close_date"], ""))
        p = parse_num(r.get(cmap["close_price"], ""))
        lp = parse_num(r.get(cmap["list_price"], ""))
        dom = parse_num(r.get(cmap["dom"], ""))
        sq = parse_num(r.get(cmap["sqft"], "")) if "sqft" in cmap else None
        ld = parse_date(r.get(cmap["list_date"], "")) if "list_date" in cmap else None
        mls = (r.get("MLS #") or r.get("MLS Number") or r.get("ML #") or "").strip()
        if d is None or p is None or p < 10_000 or p > 20_000_000 or (dom is not None and dom < 0):
            dropped += 1; continue
        if mls and mls in seen: dropped += 1; continue
        if mls: seen.add(mls)
        out.append({"close": d, "price": p, "list": lp, "dom": dom, "sqft": sq, "list_date": ld})
    return out, dropped

def window_stats(rows):
    n = len(rows)
    prices = [r["price"] for r in rows]
    doms = [r["dom"] for r in rows if r["dom"] is not None]
    stl = [r["price"] / r["list"] * 100 for r in rows if r["list"]]
    sq_rows = [r for r in rows if r["sqft"] and r["sqft"] > 250]
    ppsf = [r["price"] / r["sqft"] for r in sq_rows]
    return {
        "closed_sales": n,
        "median_price": round(med(prices)) if prices else None,
        "median_ppsf": round(med(ppsf)) if ppsf else None,
        "sqft_coverage_pct": round(len(sq_rows) / n * 100, 1) if n else None,
        "median_dom": round(med(doms)) if doms else None,
        "sale_to_list_pct": round(med(stl), 1) if stl else None,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slug", required=True)
    ap.add_argument("--solds", required=True)
    ap.add_argument("--actives", required=True)
    ap.add_argument("--run-date", default=None)
    ap.add_argument("--column-map", default="market-loop/column_map.json")
    ap.add_argument("--outdir", default="market-loop/data/metrics")
    a = ap.parse_args()

    run = datetime.strptime(a.run_date, "%Y-%m-%d") if a.run_date else datetime.now()
    user_map = json.load(open(a.column_map)) if os.path.exists(a.column_map) else {}
    rows, dropped = load_solds(a.solds, user_map)

    def between(lo, hi): return [r for r in rows if lo < r["close"] <= hi]
    ttm       = between(run - timedelta(days=365), run)
    prior     = between(run - timedelta(days=730), run - timedelta(days=365))
    pulse     = between(run - timedelta(days=90), run)
    pulse_ly  = between(run - timedelta(days=455), run - timedelta(days=365))

    with open(a.actives, newline="", encoding="utf-8-sig") as f:
        actives_n = sum(1 for _ in csv.DictReader(f))

    s_ttm, s_prior = window_stats(ttm), window_stats(prior)
    s_pulse, s_pulse_ly = window_stats(pulse), window_stats(pulse_ly)
    mos = round(actives_n / (s_ttm["closed_sales"] / 12), 1) if s_ttm["closed_sales"] else None

    n1, n2 = s_ttm["closed_sales"], s_prior["closed_sales"]
    flags = []
    if min(n1, n2) < 12: flags.append("no_deltas_tiny_sample")
    elif min(n1, n2) < 30: flags.append("small_sample_soften")
    if s_ttm["sqft_coverage_pct"] is not None and s_ttm["sqft_coverage_pct"] < 80: flags.append("sqft_coverage_low")
    dp = pct_delta(s_ttm["median_price"], s_prior["median_price"])
    if dp is not None and abs(dp) > 15 and n1 < 50:
        big = med([r["price"] for r in ttm])
        hi_share = sum(1 for r in ttm if big and r["price"] > 2 * big) / n1 * 100 if n1 else 0
        flags.append(f"possible_mix_shift_high_end_share_{round(hi_share,1)}pct")

    deltas = None if "no_deltas_tiny_sample" in flags else {
        "closed_sales_pct": pct_delta(n1, n2),
        "median_price_pct": dp,
        "median_ppsf_pct": pct_delta(s_ttm["median_ppsf"], s_prior["median_ppsf"]),
        "median_dom_days": (s_ttm["median_dom"] - s_prior["median_dom"]) if None not in (s_ttm["median_dom"], s_prior["median_dom"]) else None,
        "sale_to_list_pts": round(s_ttm["sale_to_list_pct"] - s_prior["sale_to_list_pct"], 1) if None not in (s_ttm["sale_to_list_pct"], s_prior["sale_to_list_pct"]) else None,
    }

    out = {
        "slug": a.slug, "run_date": run.strftime("%Y-%m-%d"), "dropped_rows": dropped,
        "windows": {"ttm": s_ttm, "prior_ttm": s_prior,
                    "pulse_90d": s_pulse, "pulse_90d_last_year": s_pulse_ly},
        "actives_now": actives_n, "months_of_supply": mos,
        "deltas_ttm_vs_prior": deltas, "flags": flags,
    }
    os.makedirs(a.outdir, exist_ok=True)
    path = os.path.join(a.outdir, f"{a.slug}_{out['run_date']}.json")
    json.dump(out, open(path, "w"), indent=2)
    print(f"Wrote {path}")
    print(json.dumps({"ttm_n": n1, "prior_n": n2, "flags": flags, "mos": mos}, indent=2))

if __name__ == "__main__":
    main()
