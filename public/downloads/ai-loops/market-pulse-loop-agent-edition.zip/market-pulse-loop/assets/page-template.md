---
url: /{{SLUG}}-housing-market/
title: "{{CITY}}, {{ST}} Housing Market: Prices, Trends & What They Mean (Updated {{MONTH_YEAR}})"
dateModified: {{RUN_DATE}}
---

# {{CITY}}, {{ST}} Housing Market — Updated {{MONTH_YEAR}}

{{OPENING_PARAGRAPH — unique to this city, cites its most notable number}}

## {{CITY}} at a glance

| Metric | Last 12 months | Prior 12 months | Change |
|---|---|---|---|
| Homes sold | {{TTM_SOLD}} | {{PRIOR_SOLD}} | {{D_SOLD}} |
| Median sold price | {{TTM_PRICE}} | {{PRIOR_PRICE}} | {{D_PRICE}} |
| Median price / sqft | {{TTM_PPSF}} | {{PRIOR_PPSF}} | {{D_PPSF}} |
| Median days on market | {{TTM_DOM}} | {{PRIOR_DOM}} | {{D_DOM}} |
| Sale-to-list ratio | {{TTM_STL}} | {{PRIOR_STL}} | {{D_STL}} |
| Months of supply | {{MOS}} | — | — |

*Closed-sale data pulled {{RUN_DATE}}.{{SAMPLE_NOTE}}*

## What changed in {{CITY}}

{{WHAT_CHANGED — 2–3 paragraphs, honors flags, includes 90-day pulse}}

## If you're selling in {{CITY}}

{{SELLER_SECTION — pricing-strategy implications from THESE numbers}}

## If you're buying in {{CITY}}

{{BUYER_SECTION — supply, competition, negotiability}}

## Living in {{CITY}}: what buyers ask us

{{NEIGHBORHOOD_COLOR — rotate angle each refresh}}

## {{CITY}} market FAQ

**Is {{CITY}} a buyer's or seller's market right now?**
{{FAQ_1}}

**What does the average home cost in {{CITY}}?**
{{FAQ_2}}

**How long do homes take to sell in {{CITY}}?**
{{FAQ_3}}

---
{{CTA_BLOCK — home value / pricing consult}}

**Related:** {{INTERNAL_LINKS — moving-to guide, 2–3 adjacent city market pages}}

*Market data derived from {{MLS_NAME}} closed-sale records pulled {{RUN_DATE}}. Deemed reliable but not guaranteed. Statistics are computed by {{TEAM_NAME}} and are not published or endorsed by {{MLS_NAME}}.*
