# Metrics Spec

All stats derive from the solds CSV (last 730 days of closings) plus the actives snapshot. Run date = extraction date.

## Windows

- **TTM**: closings with close date in the last 365 days.
- **Prior TTM**: closings with close date 366–730 days ago.
- **90-day pulse**: last 90 days vs the same 90-day span one year earlier.

Rolling windows are the point: they smooth seasonality and keep thin markets honest. Never compare a calendar month to another calendar month.

## Per-window metrics

| Metric | Definition |
|---|---|
| Closed sales | Count of closings in window |
| Median sold price | Median of close price |
| Median $/sqft | Median of close price ÷ interior sqft (rows with sqft > 250 only; report coverage if <80% of rows have sqft) |
| Median DOM | Median days on market |
| Sale-to-list | Median of (close price ÷ list price), as % |
| Months of supply | Current actives ÷ (TTM closings ÷ 12) — TTM only |
| New listings | Count by list date in window (only if list date column present) |

Deltas: TTM vs prior TTM as % (counts, prices, $/sqft) or point/day change (sale-to-list, DOM). Round prices to nearest $1K, ratios to 0.1%, DOM to whole days.

## Small-sample rules (non-negotiable)

- **n < 12 in either window**: no percentage deltas at all. Report counts and medians with "a handful of sales" framing; lean on the 730-day combined picture.
- **12 ≤ n < 30**: deltas allowed but every cited % carries softening ("directional," "small sample") and the page states the sale count in the same sentence.
- **n ≥ 30**: normal reporting.
- Median price swings > ±15% in markets with n < 50: check for mix shift (share of sales above 2× median) and say so — "driven by several high-end closings," not "prices exploded."
- Never annualize or extrapolate the 90-day pulse.

## Data hygiene

Drop rows with: close price < $10,000 or > $20M, DOM < 0, missing close date. Report dropped-row count in the metrics JSON. Duplicate MLS numbers: keep latest close date.

## Output

`compute_metrics.py` writes `market-loop/data/metrics/<slug>_<YYYY-MM-DD>.json` containing every metric for all three windows, deltas, flags (small_sample, mix_shift, sqft_coverage_low), and dropped-row counts. Pages cite only what's in this JSON.
