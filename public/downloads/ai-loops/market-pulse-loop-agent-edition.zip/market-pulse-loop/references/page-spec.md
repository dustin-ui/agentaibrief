# Page Spec — Evergreen Market Pages

## The prime directive

One fixed URL per city, refreshed in place: `/<slug>-housing-market/` (align with the site's established evergreen URL conventions if they differ). Title pattern: **"<City>, <ST> Housing Market: Prices, Trends & What They Mean (Updated <Month Year>)"**. The month lives in the title text and `dateModified` — never in the URL. Dated URLs recreate the news-decay problem this loop exists to fix.

## Structure (every page, this order)

1. **At-a-glance table** — TTM vs prior TTM: closed sales, median price, median $/sqft, median DOM, sale-to-list, months of supply, each with delta. Pull date beneath.
2. **What changed** — 2–3 short paragraphs interpreting the deltas, honoring every small-sample flag. Include the 90-day pulse as "right now" color.
3. **If you're selling in <City>** — pricing-strategy implications in your team's voice: what the DOM and sale-to-list numbers mean for list-price strategy this quarter.
4. **If you're buying in <City>** — supply, competition, negotiability.
5. **Neighborhood color** — 1 paragraph of genuinely local texture (anchors, commute reality, what buyers actually ask). Rotate the angle each refresh.
6. **FAQ** (3–4, FAQPage schema) — phrased as real queries: "Is <City> a buyer's or seller's market right now?", "What does the average home cost in <City>?", "How long do homes take to sell in <City>?"
7. **CTA** — pricing consult / home-value link.
8. **Internal links** — the city's moving-to guide, 2–3 adjacent-city market pages, one relevant service page.
9. **Attribution & disclaimer** (exact, every page): "Market data derived from {{MLS_NAME}} closed-sale records pulled <date>. Deemed reliable but not guaranteed. Statistics are computed by {{TEAM_NAME}} and are not published or endorsed by {{MLS_NAME}}." Check your MLS rules — many require specific attribution/disclaimer wording; use theirs verbatim if so.

## Schema

`Article` (or `AnalysisNewsArticle`) with `dateModified` = run date and `datePublished` preserved from first publication; `FAQPage` for section 6; `BreadcrumbList`. If your CMS allows raw JSON-LD, emit it in the HTML variant; otherwise use its native fields.

## The anti-doorway rules

150 stat pages live or die on differentiation. Hard rules:

- **No two pages share an opening sentence structure in the same week.** Check `memory.md`'s recent openings before writing.
- Every interpretive claim cites a number from *this city's* metrics JSON in the same paragraph.
- At least one sentence per page could only be true of this city (anchor, corridor, school pyramid, price-band quirk).
- Section 3/4 advice must follow from the data shown — if months of supply fell 20%, the seller section says something different than where it rose.
- Word count is an output, not a target; 700–1,100 words is typical. Never pad.

## Refresh behavior

On refresh: update table, rewrite sections 2–4 fresh from new data, rotate section 5's angle, keep FAQ unless the answer changed, bump `dateModified`, and append one line to `memory.md` (city, date, notable stat, opening angle used).
