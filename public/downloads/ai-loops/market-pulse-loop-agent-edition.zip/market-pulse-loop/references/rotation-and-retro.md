# Rotation & Weekly Retro

## Daily rotation
Order: never-published > priority weight > staleness. Weights: 1.0 default; 1.5 for pages at GSC positions 5–15 (page-two, close to breaking through); 0.7 for stable page-one leaders (protect, don't churn); 0.5 for sub-position-30 pages pending structural rethink.

## Weekly retro inputs
GSC performance for market-page URLs (API if connected, else user-provided export): clicks, impressions, position, WoW deltas per page.

## Retro outputs
1. Updated priority weights in cities.json (with one-line reasons).
2. memory.md appendix: openings/sections that won snippets or AI citations; angle patterns by city type (commuter suburb vs luxury vs townhome-heavy).
3. Flag list: pages stuck <30 after 3 refreshes -> structural rethink, not another refresh.
4. One experiment for next week (e.g., test question-led H1 on 3 pages) with its check date.
