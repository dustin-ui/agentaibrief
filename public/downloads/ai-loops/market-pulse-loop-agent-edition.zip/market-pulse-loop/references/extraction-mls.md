# Extraction — your MLS via your own session

The user pulls data with their own MLS subscriber login (works the same for Bright, Stellar, CRMLS, NTREIS, ARMLS, etc.). Automating your own licensed access is the user's call; most MLSs restrict some automated access, so keep volume human-scale (5 cities/day is fine), never parallelize aggressively, and if the account is ever challenged, drop to the manual CSV lane and ask the MLS about official data products (many offer a RESO Web API under your broker's data license — the sturdiest long-term lane).

## Architecture: isolate the fragile part
Only one module touches the MLS website: [scripts/mls_extract.py](../scripts/mls_extract.py). Everything downstream (compute, write, retro) reads CSVs and never knows where they came from. When the MLS changes its UI, one file gets repaired and the loop keeps its memory.

## First-time setup (interactive, once)
1. `pip install playwright && playwright install chromium`
2. Record the real clickpath with codegen against a persistent profile:
   `playwright codegen --user-data-dir=~/.market-loop-profile https://<your-mls-portal>`
   Log in (completing any 2FA once — the profile keeps the session), then perform the search once while codegen records: **Residential → Closed/Sold → close date in the last 730 days → [one city/area] → results → Export CSV**, and separately **Residential → Active → [same city] → Export CSV**.
3. Paste the recorded steps into `mls_extract.py` where marked `# --- RECORDED CLICKPATH ---`, parameterizing the city field and date range. Test on 2 cities headed, then run headless.
4. Store the login only in the local `.env` (`MLS_USER`, `MLS_PASS`) for session-refresh; the persistent profile means most runs never touch the login form.

## Run behavior
- Sequential cities, polite pacing (the script enforces delays; do not remove them).
- Session expired → script pauses and asks for interactive re-auth, then resumes.
- Selector failure → screenshot to `market-loop/data/errors/`, skip the city, report it. Never guess at data.
- Exports land as `market-loop/data/raw/<slug>/solds_730d_<date>.csv` and `actives_<date>.csv`.

## Column mapping
Export headers vary by MLS and profile settings. On first ingest, `compute_metrics.py` prints unmatched columns; maintain the mapping in `market-loop/column_map.json`. Required fields: close date, close price, list price, days on market, interior sqft (optional but preferred), list date (optional, enables new-listings count).

## Fallback lane (always available)
Anyone — the user or a VA — can pull the same two exports manually and drop them in `market-loop/data/inbox/` named `<slug>_solds.csv` / `<slug>_actives.csv`. The loop ingests, archives to `raw/`, and proceeds identically.

## Optional: CMS publish step
Same pattern, separate profile (`~/.cms-loop-profile`), separate script recorded with codegen against your site's blog editor (Sierra, kvCORE, WordPress, etc.): new post → title → body paste → category → publish. Off by default; runs only on explicit per-batch confirmation. Until recorded, the outbox files are the deliverable.
