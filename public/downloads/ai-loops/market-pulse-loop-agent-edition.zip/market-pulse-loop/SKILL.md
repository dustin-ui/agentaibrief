---
name: market-pulse-loop
description: Run the daily hyperlocal market-report loop for a real estate team — pull MLS residential sold data with the user's own logged-in session (or ingest dropped CSV exports), compute trailing-12-month vs prior-12-month stats for 5 cities per day, write or refresh one evergreen housing-market page per city on a fixed URL, and run a weekly retro against Google Search Console to reorder the city rotation. Use whenever the user says run the market loop, refresh market pages, pull MLS stats, write city market updates, or asks for hyperlocal market blogs — even casually, like "do today's five cities."
---

# Market Pulse Loop

Five cities a day. One evergreen URL per city, updated in place — never a dated news post. On first run, build the city list for the team's market and confirm slugs before publishing anything. Rolling 365-day windows compared year-over-year so thin markets read honestly. A weekly retro that learns which pages climb and feeds that back into the rotation.

Read [references/metrics-spec.md](references/metrics-spec.md) before computing anything, and [references/page-spec.md](references/page-spec.md) before writing any page. Extraction details live in [references/extraction-mls.md](references/extraction-mls.md).

## Loop state (working directory)

- `market-loop/cities.json` — the city list with slugs, jurisdictions, priority weights, and last-refreshed dates. Create from [data/cities.template.json](data/cities.template.json) on first run by asking the user for their market's cities/submarkets (aim for 30–150).
- `market-loop/memory.md` — running log: what was published, what the retro learned, phrasing/angles that won snippets or citations.
- `market-loop/data/raw/<slug>/` — extracted CSVs. `market-loop/data/inbox/` — manual CSV drop folder (fallback lane).
- `market-loop/outbox/` — finished pages awaiting publish. `market-loop/published/` — archive after the user confirms posting.

## Daily run

### 1. Pick today's five

Sort `cities.json` by: (a) never-published first, (b) then highest priority weight, (c) then longest since refresh. Priority weights come from the weekly retro — cities ranking positions 5–15 in Search Console get boosted because they're closest to page one. Announce the five picks before extracting.

### 2. Extract

Follow [references/extraction-mls.md](references/extraction-mls.md). Per city, two pulls: **solds, closed in the last 730 days** (one export covers both comparison windows) and a **current actives snapshot**. Save CSVs to `market-loop/data/raw/<slug>/`. If automation is unavailable or fails, check `market-loop/data/inbox/` for manually dropped exports and say exactly which files are needed. Never fabricate or extrapolate numbers — no data, no page.

### 3. Compute

Run [scripts/compute_metrics.py](scripts/compute_metrics.py) per city. It produces a metrics JSON: TTM vs prior-TTM closed count, median sold price, median $/sqft, median DOM, sale-to-list ratio, months of supply, a trailing-90-day pulse, and small-sample flags. Respect every flag per the metrics spec — a 40-sale-a-year enclave gets softer language than a 900-sale suburb.

### 4. Write or refresh the page

Fill [assets/page-template.md](assets/page-template.md) per the page spec. Same URL every time (`/<slug>-housing-market/` or the user's established evergreen URL convention), updated `dateModified`, fresh interpretation. The interpretation layer is what keeps 150 stat pages from being thin templated content: every page opens differently, cites its own numbers, and says something your team would actually say about *that* market. Consult `memory.md` for angles that have been winning.

### 5. Stage and summarize

Write finished pages to `market-loop/outbox/<slug>.md` (plus an HTML variant if the user publishes by paste into their site's blog/CMS). Update `cities.json` timestamps. Tell the user: the five cities, the single most notable stat movement of the day, and anything that needs a human (missing data, sample-size concerns, publish confirmations).

Publishing is the human's step by default. If the user has set up the optional CMS publish automation (see extraction reference, same persistent-session pattern), run it only after they confirm the batch.

## Weekly retro (every 7th run, or on request)

Pull Search Console data for the market pages (API if connected; otherwise ask for a performance export covering `/-housing-market/` URLs). For each page: clicks, impressions, average position, week-over-week delta. Then:

- Boost priority weights for pages at positions 5–15; note pages that jumped or slid and inspect what their last update did differently.
- Append findings to `memory.md`: winning openings, sections earning featured snippets, FAQ phrasings surfacing in AI answers.
- Flag pages stuck below position 30 after 3+ refreshes for a structural rethink rather than another refresh.

## Modes

- `daily` (default): 5 cities, full pipeline.
- `catchup N`: run N cities (e.g., seeding week).
- `retro`: weekly retro only.
- `single <city>`: one city on demand (e.g., ahead of a listing appointment there).
- `audit`: recompute all published pages' staleness and list the 10 most overdue.

## Hard rules

- Real extracted data only. A failed pull halts that city's page; it never estimates.
- Every page carries the MLS source attribution required by the user's MLS, the pull date, and the accuracy disclaimer (page spec has exact language).
- One evergreen URL per city forever. Never create dated variants; never change a slug without being asked.
- Credentials live in the local `.env`/keychain only — never in skill files, outputs, logs, or memory.
- Respect small-sample flags in every sentence that cites a percentage.
