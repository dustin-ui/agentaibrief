# Market Pulse Loop
Daily loop: 5 cities/day from your own MLS login (any MLS) -> trailing-12-month vs prior-12-month stats with small-sample guards -> one evergreen /city-housing-market/ page updated in place -> weekly Search Console retro reorders the rotation.
Install: cp -R market-pulse-loop ~/.codex/skills/
Setup: pip install playwright && playwright install chromium; record your MLS clickpath once (see references/extraction-mls.md); build your city list on first run. No automation? Drop manual CSV exports in market-loop/data/inbox/.
Check your MLS rules on data display; use its required attribution wording on every page.
Run: "Use $market-pulse-loop to run today's five cities."
