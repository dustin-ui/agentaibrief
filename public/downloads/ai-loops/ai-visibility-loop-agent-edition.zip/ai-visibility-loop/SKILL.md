---
name: ai-visibility-loop
description: Run the AI Visibility loop for a real estate team — execute a tracked set of ~50 local real estate queries across AI answer engines (ChatGPT, Perplexity, Gemini, Google AI Mode), score whether the team or its website gets mentioned or cited versus competitors, then rewrite and re-schema the target pages most likely to win lost queries, and produce the weekly AI Visibility Report Card with movement. Use whenever the user asks to run the visibility loop, check AI citations, run the report card, see how the team shows up in ChatGPT/Perplexity/Gemini, or improve AEO/GEO — even casually, like "are we showing up in AI yet?"
---

# AI Visibility Loop

The objective metric: of all tracked query × engine pairs, in how many does your brand appear — and with which page cited? Everything else exists to push that number up. Weekly cadence: run queries → score → pick battles → improve pages → log the experiment → re-measure next week.

Read [references/query-tracking.md](references/query-tracking.md) before running queries and [references/improvement-playbook.md](references/improvement-playbook.md) before touching any page.

## Loop state (working directory)

- `ai-visibility/queries.json` — tracked queries with category, intent, and target URL. On first run, generate ~50 from [data/query-frames.seed.json](data/query-frames.seed.json) using the user's cities, county, metro, and brand names — then confirm the list with them.
- `ai-visibility/config.json` — brand patterns and competitor names to detect. Seed from [data/config.seed.json](data/config.seed.json); on first run fill brand_patterns, brand_domains, and competitors with the user.
- `ai-visibility/runs/<date>/*.jsonl` — raw query results per engine.
- `ai-visibility/scores/` — weekly scorecard JSONs from the scoring script.
- `ai-visibility/memory.md` — experiments log: page changed, hypothesis, queries targeted, result at next measurement.

## Weekly run

### 1. Execute the tracked queries

Follow the lanes in [references/query-tracking.md](references/query-tracking.md) (API where keys exist, recorded browser sessions, or the VA paste inbox). Each result row: date, engine, query_id, full response text, and any URLs the engine cited. Partial coverage is fine — score what ran, and report which engine × query pairs are missing rather than guessing.

### 2. Score

Run [scripts/score_visibility.py](scripts/score_visibility.py) on the runs folder. It detects brand mentions and citations (patterns from config), competitor mentions, and which URL got cited, then computes: **Visibility Score** (% of pairs where the brand appears), **Citation Share** (brand mentions ÷ brand + competitor mentions), per-engine and per-category breakdowns, and movement vs the prior scorecard.

### 3. Pick this week's battles

From the scorecard, choose up to **5 target queries** where the gap is winnable: high-intent queries where competitors appear and the brand doesn't, or where the brand is mentioned but the wrong/weak page is cited. Prefer queries whose target page already exists (a market-pulse city page, a moving-to guide, a service page). Never spread across more than 5 — the loop learns nothing from shotgun changes.

### 4. Improve the target pages

Apply the playbook: answer-first rewrites, query-matching H2s, FAQ schema, citable stats (link the market-pulse pages — engines love numbers with dates), entity consistency, dateModified bumps. Stage edits in `ai-visibility/outbox/` for the user to publish (or via a recorded CMS session, per-batch confirmation). Log each change in `memory.md` with its hypothesis and the queries it targets.

### 5. Report card

Produce `ai-visibility/reports/<date>-report-card.html`: headline Visibility Score with delta, Citation Share vs each competitor, per-engine table, this week's battles and edits, last week's experiments graded (won the citation / no change / lost ground), and the missing-coverage list. Plain enough that a partner or ops lead can read it in two minutes.

## Modes

- `weekly` (default): full loop.
- `measure-only`: run + score, no page edits.
- `spot-check "<query>"`: run one query across all available engines right now and report.
- `add-queries`: expand the tracked set (keep total ≤75 so movement stays readable).

## Hard rules

- Never fabricate an engine response. No run, no score — say which pairs are missing.
- Grade last week's experiments before starting new ones; the learning is the loop.
- Max 5 page edits per week, each tied to named queries in `memory.md`.
- Brand/competitor detection lives in config, not in code edits.
- Engine accounts and API keys live in local `.env` only.
