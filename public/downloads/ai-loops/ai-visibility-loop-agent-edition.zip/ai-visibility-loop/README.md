# AI Visibility Loop
Weekly loop: run ~50 tracked local real estate queries across AI engines (Perplexity/Gemini APIs, recorded ChatGPT/AI Mode sessions, or a VA paste inbox) -> score brand mentions/citations vs competitors -> pick 5 winnable battles -> improve those pages with logged hypotheses -> grade last week's experiments -> report card.
Install: cp -R ai-visibility-loop ~/.codex/skills/
First run: fill data config (brand patterns, brand domains, competitors) and generate your ~50 queries from data/query-frames.seed.json using your cities and brand.
Run: "Use $ai-visibility-loop to run this week's loop."
