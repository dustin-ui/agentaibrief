#!/usr/bin/env python3
"""score_visibility.py — AI Visibility Loop scoring engine.

Usage:
  python score_visibility.py --runs ai-visibility/runs/2026-07-13 \
      --queries ai-visibility/queries.json --config ai-visibility/config.json \
      [--prev ai-visibility/scores/<last>.json] [--outdir ai-visibility/scores]

Input: one or more *.jsonl files in --runs, rows like
  {"date","engine","query_id","query","response_text","cited_urls":["..."]}
Output: scorecard JSON with Visibility Score, Citation Share, per-engine and
per-category tables, per-query detail, and movement vs --prev.
"""
import argparse, glob, json, os, re, sys
from collections import defaultdict

def norm(t): return re.sub(r"\s+", " ", (t or "").lower())

def hit(text, patterns): return any(p in text for p in patterns)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--queries", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--prev", default=None)
    ap.add_argument("--outdir", default="ai-visibility/scores")
    a = ap.parse_args()

    cfg = json.load(open(a.config))
    brand = [norm(p) for p in cfg["brand_patterns"]]
    brand_domains = [d.lower() for d in cfg.get("brand_domains", [])]
    comps = {k: [norm(x) for x in v] for k, v in cfg["competitors"].items() if not k.startswith("_")}
    qmeta = {q["id"]: q for q in json.load(open(a.queries))["queries"]}

    rows = []
    for path in sorted(glob.glob(os.path.join(a.runs, "*.jsonl"))):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    if not rows:
        sys.exit(f"No JSONL rows found in {a.runs}")

    detail, run_date = [], rows[0].get("date", "")
    for r in rows:
        text = norm(r.get("response_text", ""))
        urls = " ".join(r.get("cited_urls", []) or []).lower()
        mentioned = hit(text, brand)
        cited = any(bd in urls for bd in brand_domains)
        comp_hits = sorted(k for k, pats in comps.items() if hit(text, pats))
        cited_brand_urls = [u for u in (r.get("cited_urls") or [])
                            if any(bd in u.lower() for bd in brand_domains)]
        detail.append({
            "query_id": r["query_id"], "engine": r["engine"],
            "category": qmeta.get(r["query_id"], {}).get("category", "unknown"),
            "query": r.get("query") or qmeta.get(r["query_id"], {}).get("query", ""),
            "brand_mentioned": mentioned, "brand_cited": cited,
            "brand_cited_urls": cited_brand_urls, "competitors_mentioned": comp_hits,
        })

    def agg(items):
        n = len(items)
        vis = sum(1 for d in items if d["brand_mentioned"] or d["brand_cited"])
        brand_n = sum(1 for d in items if d["brand_mentioned"] or d["brand_cited"])
        comp = sum(len(d["competitors_mentioned"]) for d in items)
        share = round(brand_n / (brand_n + comp) * 100, 1) if (brand_n + comp) else None
        return {"pairs": n, "visibility_pct": round(vis / n * 100, 1) if n else None,
                "citation_share_pct": share}

    by_engine = {e: agg([d for d in detail if d["engine"] == e])
                 for e in sorted({d["engine"] for d in detail})}
    by_cat = {c: agg([d for d in detail if d["category"] == c])
              for c in sorted({d["category"] for d in detail})}
    per_comp = {k: sum(1 for d in detail if k in d["competitors_mentioned"]) for k in comps}

    expected = {(q, e) for q in qmeta for e in by_engine}
    got = {(d["query_id"], d["engine"]) for d in detail}
    missing = sorted(expected - got)

    losses = [d for d in detail if not (d["brand_mentioned"] or d["brand_cited"]) and d["competitors_mentioned"]]
    battle_counts = defaultdict(lambda: {"engines": 0, "comps": set(), "query": "", "category": ""})
    for d in losses:
        b = battle_counts[d["query_id"]]
        b["engines"] += 1; b["comps"].update(d["competitors_mentioned"])
        b["query"], b["category"] = d["query"], d["category"]
    battles = sorted(
        ({"query_id": k, **{kk: (sorted(vv) if isinstance(vv, set) else vv) for kk, vv in v.items()}}
         for k, v in battle_counts.items()),
        key=lambda x: (-x["engines"], x["query_id"]))[:10]

    card = {"run_date": run_date, "overall": agg(detail), "by_engine": by_engine,
            "by_category": by_cat, "competitor_mentions": per_comp,
            "suggested_battles": battles, "missing_pairs": [list(m) for m in missing],
            "detail": detail}

    if a.prev and os.path.exists(a.prev):
        prev = json.load(open(a.prev))
        card["movement"] = {
            "visibility_pct_delta": round((card["overall"]["visibility_pct"] or 0) -
                                          (prev["overall"]["visibility_pct"] or 0), 1),
            "citation_share_delta": round((card["overall"]["citation_share_pct"] or 0) -
                                          (prev["overall"]["citation_share_pct"] or 0), 1),
            "newly_won": sorted({(d["query_id"], d["engine"]) for d in detail if d["brand_mentioned"] or d["brand_cited"]} -
                                {(d["query_id"], d["engine"]) for d in prev["detail"] if d["brand_mentioned"] or d["brand_cited"]}),
            "newly_lost": sorted({(d["query_id"], d["engine"]) for d in prev["detail"] if d["brand_mentioned"] or d["brand_cited"]} -
                                 {(d["query_id"], d["engine"]) for d in detail if d["brand_mentioned"] or d["brand_cited"]}),
        }

    os.makedirs(a.outdir, exist_ok=True)
    out = os.path.join(a.outdir, f"scorecard_{run_date or 'undated'}.json")
    json.dump(card, open(out, "w"), indent=2)
    print(f"Wrote {out}")
    print(json.dumps({"overall": card["overall"], "by_engine": by_engine,
                      "top_battles": [b["query"] for b in battles[:5]],
                      "missing_pairs": len(missing)}, indent=2))

if __name__ == "__main__":
    main()
