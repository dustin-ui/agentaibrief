#!/usr/bin/env python3
"""run_queries.py — execute tracked queries. Lane 1 (APIs) implemented for
Perplexity + Gemini; Lane 2 (recorded browser) is a marked scaffold like the
market-pulse MLS extractor; Lane 3 (VA paste inbox) ingestion included.

Env: PPLX_API_KEY, GEMINI_API_KEY (either optional; runs what it has).
NOTE: verify current model names/endpoints against provider docs before first
run — they change. Failures are recorded as missing pairs, never faked.

Usage:
  python run_queries.py --queries ai-visibility/queries.json --date 2026-07-13 \
      --engines perplexity gemini --outdir ai-visibility/runs/2026-07-13
  python run_queries.py --ingest-inbox ai-visibility/inbox/2026-07-13 --date 2026-07-13 \
      --queries ai-visibility/queries.json --outdir ai-visibility/runs/2026-07-13
"""
import argparse, json, os, time, glob

def jl(path, row):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")

def perplexity(query):
    import urllib.request
    req = urllib.request.Request(
        "https://api.perplexity.ai/chat/completions",
        headers={"Authorization": f"Bearer {os.environ['PPLX_API_KEY']}",
                 "Content-Type": "application/json"},
        data=json.dumps({"model": "sonar",  # verify current search model name
                         "messages": [{"role": "user", "content": query}]}).encode())
    d = json.load(urllib.request.urlopen(req, timeout=120))
    text = d["choices"][0]["message"]["content"]
    cites = d.get("citations") or d.get("search_results") or []
    urls = [c if isinstance(c, str) else c.get("url", "") for c in cites]
    return text, urls

def gemini(query):
    import urllib.request
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           "gemini-2.0-flash:generateContent?key=" + os.environ["GEMINI_API_KEY"])  # verify model
    body = {"contents": [{"parts": [{"text": query}]}],
            "tools": [{"google_search": {}}]}
    req = urllib.request.Request(url, headers={"Content-Type": "application/json"},
                                 data=json.dumps(body).encode())
    d = json.load(urllib.request.urlopen(req, timeout=120))
    cand = d["candidates"][0]
    text = "".join(p.get("text", "") for p in cand["content"]["parts"])
    urls = []
    gm = cand.get("groundingMetadata", {})
    for ch in gm.get("groundingChunks", []):
        u = ch.get("web", {}).get("uri", "")
        if u: urls.append(u)
    return text, urls

def browser_lane(engine, query):
    """Lane 2 scaffold. Record with:
       playwright codegen --user-data-dir=~/.aivis-chatgpt https://chatgpt.com
    then implement per engine. Until then this lane reports unavailable."""
    raise NotImplementedError(f"browser lane for {engine} not recorded yet")

ENGINES = {"perplexity": ("PPLX_API_KEY", perplexity),
           "gemini": ("GEMINI_API_KEY", gemini),
           "chatgpt": (None, lambda q: browser_lane("chatgpt", q)),
           "aimode": (None, lambda q: browser_lane("aimode", q))}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--queries", required=True)
    ap.add_argument("--date", required=True)
    ap.add_argument("--engines", nargs="*", default=["perplexity", "gemini"])
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--ingest-inbox", default=None)
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    qs = json.load(open(a.queries))["queries"]

    if a.ingest_inbox:
        n = 0
        for path in glob.glob(os.path.join(a.ingest_inbox, "*", "*.txt")):
            engine = os.path.basename(os.path.dirname(path))
            qid = os.path.splitext(os.path.basename(path))[0]
            lines = open(path, encoding="utf-8").read().splitlines()
            jl(os.path.join(a.outdir, f"{engine}.jsonl"),
               {"date": a.date, "engine": engine, "query_id": qid,
                "query": lines[0] if lines else "",
                "response_text": "\n".join(lines[1:]), "cited_urls": []})
            n += 1
        print(f"Ingested {n} inbox files"); return

    for engine in a.engines:
        keyname, fn = ENGINES[engine]
        if keyname and not os.environ.get(keyname):
            print(f"[skip] {engine}: {keyname} not set"); continue
        out = os.path.join(a.outdir, f"{engine}.jsonl")
        for q in qs:
            try:
                text, urls = fn(q["query"])
                jl(out, {"date": a.date, "engine": engine, "query_id": q["id"],
                         "query": q["query"], "response_text": text, "cited_urls": urls})
                print(f"[ok] {engine} {q['id']}")
            except NotImplementedError as e:
                print(f"[unavailable] {e}"); break
            except Exception as e:
                print(f"[fail] {engine} {q['id']}: {type(e).__name__}: {e}")
            time.sleep(3)

if __name__ == "__main__":
    main()
