# Query Tracking — running the set across engines

Three lanes; use whichever are configured, in this order of reliability. Every lane produces the same JSONL row format: {"date","engine","query_id","query","response_text","cited_urls":[...]}.

## Lane 1 — APIs (cheapest, most consistent)
- **Perplexity**: chat completions with a `sonar` search model; capture answer text + returned citations. Requires PPLX_API_KEY in .env (see scripts/run_queries.py; verify current model names against their docs).
- **Gemini**: generate with Google Search grounding enabled; capture text + grounding source URLs. Requires GEMINI_API_KEY.
API answers may differ slightly from the consumer apps; that's acceptable — week-over-week consistency matters more than perfect parity.

## Lane 2 — Recorded browser sessions (consumer parity)
Same pattern as the market-pulse MLS extractor: persistent profile per engine, one codegen recording of "type query, wait for answer, copy answer + sources," parameterized. Profiles: ~/.aivis-chatgpt, ~/.aivis-aimode. Pace 30–60s between queries; if an engine challenges the session, drop it to Lane 3 this week rather than fighting it.

## Lane 3 — VA paste inbox (always works)
`ai-visibility/inbox/<date>/<engine>/<query_id>.txt` — first line the query, rest the pasted answer including sources. A VA clears 50 queries x 2 engines in under an hour. The loop ingests these into JSONL.

## Consistency rules
Full set weekly, same weekday. If capacity is tight, engines may rotate but ChatGPT and Google AI Mode never skip two consecutive weeks (largest audiences). Log run conditions (logged-in vs logged-out, region) — they affect answers and must stay constant week to week.
