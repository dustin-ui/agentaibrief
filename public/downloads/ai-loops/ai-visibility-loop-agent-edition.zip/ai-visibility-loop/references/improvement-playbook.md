# Improvement Playbook — winning a citation

Diagnose per lost query, in order:

1. **No page answers it** -> create/assign one (often a market-pulse city page or moving-to guide already fits; else queue the topic to the evergreen-content-loop).
2. **Page exists but buries the answer** -> answer-first rewrite: a 2–3 sentence direct answer under an H2 that mirrors the query phrasing, then depth. Engines quote paragraphs that stand alone.
3. **No citable facts** -> add dated, sourced numbers (median price, DOM, months of supply — link the market-pulse page; keep the stat and its date in the same sentence).
4. **Schema gaps** -> FAQPage on Q&A blocks, Article dateModified current, RealEstateAgent/Organization entity data consistent sitewide (name, area served, review count).
5. **Staleness** -> engines discount old pages on "right now" queries; a substantive refresh + dateModified bump often flips a near-miss.
6. **Authority gap** (competitor cited via press or directories) -> note for the press effort; page edits alone won't win these. Say so in the report instead of burning an edit slot.

Rules: one hypothesis per edit, logged in memory.md with its target queries. Before editing any page, check which queries currently cite it — protect winners. Never stuff the brand name; engines cite pages that answer, not pages that advertise.
