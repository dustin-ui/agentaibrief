#!/usr/bin/env python3
"""score_topics.py — Evergreen Content Loop scoring engine.

Usage:
  python score_topics.py --candidates content-loop/candidates/2026-07-13.raw.json \
      --content-map content-loop/content-map.json [--top 5] [--out <path>]

Candidates file: {"candidates":[{"keyword","volume","difficulty","trend",
"source","gsc_position","intent","frame","city","evergreen": true/false/null,
"notes"}]}  (nulls fine; "evergreen" may be pre-judged by the agent — the
gate below re-checks the obvious fails.)
Content map: {"posts":[{"url","primary_keyword","category","published","refreshed"}]}
Output: ranked list with per-factor scores, gate/cannibalization verdicts.
"""
import argparse, json, re

NEWS_TELLS = re.compile(
    r"\b(opens?|opening|closes?|closing|announces?|announced|coming to|breaks? ground|"
    r"grand opening|this (week|month|weekend)|event|festival|concert|ribbon)\b", re.I)
STOP = set("the a an in of for to and or vs with near best top guide what how is are".split())

def toks(s): return {t for t in re.sub(r"[^a-z0-9 ]", " ", (s or "").lower()).split() if t not in STOP}

def gate(c):
    if c.get("evergreen") is False: return False, "marked non-evergreen"
    if NEWS_TELLS.search(c.get("keyword", "")): return False, "news-pattern keyword"
    return True, "passes"

def cannibal(c, posts):
    ct = toks(c["keyword"])
    if not ct: return None
    best, score = None, 0.0
    for p in posts:
        pt = toks(p.get("primary_keyword", "")) | toks(p.get("url", "").rsplit("/", 1)[-1].replace("-", " "))
        if not pt: continue
        j = len(ct & pt) / len(ct | pt)
        if j > score: best, score = p, j
    if best and score >= 0.5:
        return {"url": best["url"], "overlap": round(score, 2)}
    return None

def score(c):
    s, why = {}, []
    vol = c.get("volume") or 0
    gsc = c.get("gsc_position")
    demand = min(30, 6 + 6 * (len(str(int(vol))) - 1)) if vol else (14 if gsc else 8)
    if "?" in c.get("keyword", "") or re.match(r"(?i)^(how|what|is|are|should|can|do|does|why|when)\b", c.get("keyword", "")):
        demand = min(30, demand + 5); why.append("question keyword")
    s["demand"] = demand

    kd = c.get("difficulty")
    win = 12 if kd is None else max(3, 25 - int(kd // 5))
    if gsc and 8 <= gsc <= 30: win = min(25, win + 10); why.append(f"GSC pos {gsc}")
    s["winnability"] = min(25, win)

    intent = (c.get("intent") or "").lower()
    s["fit"] = {"seller": 20, "mixed": 15, "buyer": 13, "relocation-buyer": 14}.get(intent, 10)

    kw = c.get("keyword", "").lower()
    dur = 12
    if any(w in kw for w in ("tax", "school", "commute", "closing costs", "hoa", "pyramid")): dur = 15
    if re.search(r"20\d\d", kw): dur = max(8, dur - 3); why.append("year-stamped: refresh annually")
    s["durability"] = dur

    s["balance"] = 8  # neutral default; the agent adjusts ±5 vs content-map category coverage
    total = sum(s.values())
    return total, s, why

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", required=True)
    ap.add_argument("--content-map", required=True)
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    cands = json.load(open(a.candidates))["candidates"]
    posts = json.load(open(a.content_map)).get("posts", [])

    ranked = []
    for c in cands:
        ok, reason = gate(c)
        if not ok:
            ranked.append({**c, "gate": "FAIL", "gate_reason": reason, "total": -1}); continue
        can = cannibal(c, posts)
        total, parts, why = score(c)
        ranked.append({**c, "gate": "PASS", "total": total, "scores": parts,
                       "rationale": "; ".join(why) or "solid across factors",
                       "action": (f"REFRESH {can['url']} (overlap {can['overlap']})" if can else "NEW POST")})
    ranked.sort(key=lambda x: -x["total"])
    picks = [r for r in ranked if r["total"] >= 0][: a.top]

    out = {"picked": picks, "write_now": picks[:3], "bench": picks[3:],
           "gated_out": [r for r in ranked if r["total"] < 0], "all": ranked}
    path = a.out or a.candidates.replace(".raw", "").replace(".json", ".scored.json")
    json.dump(out, open(path, "w"), indent=2)
    print(f"Wrote {path}")
    for r in picks:
        print(f"{r['total']:>3}  {r['action']:<12.12}  {r['keyword']}  [{r['rationale']}]")

if __name__ == "__main__":
    main()
