---
name: evergreen-content-loop
description: Run the daily evergreen content loop for a real estate site — research topic demand from SEMrush, YouTube, and Google Search Console, score candidates for durability and fit, pick the day's top 5, WRITE THE BEST 3 as complete publish-ready evergreen blog posts, and run a weekly retro that learns from what's climbing to steer tomorrow's picks. Use whenever the user asks to run the content loop, find blog topics, write today's posts, do content research, or fix the evergreen-vs-news traffic problem — even casually, like "what are we writing today?"
---

# Evergreen Content Loop

Three finished evergreen posts a day, chosen from five researched candidates, judged weekly by Search Console. The whole point is durability: content that answers what people will still be searching in two years — not restaurant openings and development news that spike and die.

Read [references/topic-scoring.md](references/topic-scoring.md) before scoring and [references/writing-spec.md](references/writing-spec.md) before writing. Research lanes are in [references/research-sources.md](references/research-sources.md).

## Loop state (working directory)

- `content-loop/content-map.json` — every published post: URL, primary keyword, category, publish/refresh dates. Build it on first run from the site's sitemap/blog index; it is the cannibalization guard.
- `content-loop/memory.md` — what's working: winning frames, categories, openings, internal-link patterns; retro findings.
- `content-loop/candidates/<date>.json` — the day's researched candidates with scores.
- `content-loop/outbox/` — finished posts awaiting publish; `content-loop/published/` after confirmation.

## Daily run

### 1. Research

Pull from the lanes in [references/research-sources.md](references/research-sources.md): SEMrush (keyword gaps vs competitors, question keywords, rising local-market terms), YouTube demand (search suggestions and view-heavy evergreen titles in the niche), and GSC (queries with impressions but weak position — page-two opportunities). Combine with the frame bank in [data/topic-frames.seed.json](data/topic-frames.seed.json) applied to your market's cities and audiences. Gather 15–25 raw candidates with whatever volume/difficulty/trend data the lanes provide.

### 2. Score and pick five

Run [scripts/score_topics.py](scripts/score_topics.py) with the candidates and content map. It applies the evergreen test (hard gate), demand, winnability, business fit, and the cannibalization check. Present the top 5 with one-line rationales. If a candidate overlaps an existing URL, the pick becomes **refresh that URL** rather than a new post — refreshes count toward the day's three.

### 3. Write the best three

Full posts per the writing spec: answer-first, question H2s that mirror real queries, FAQ schema block, dated stats citing the market-pulse pages where relevant, internal links (city guides, market pages, service pages), agent-voice interpretation, unique opening (check `memory.md` for this week's openings). 1,200–1,800 words typical; never padded. The two unwritten candidates go on the bench in the day's candidates file for future consideration.

### 4. Stage and summarize

Posts land in `content-loop/outbox/<slug>.md` (+ HTML variant for CMS paste, or a recorded CMS publish session on per-batch confirmation — same profile as market-pulse-loop). Update the content map with the three new/refreshed entries. Tell the user: today's three titles, the two benched, and any human calls needed.

## Weekly retro (every 7th run or on request)

Against GSC: clicks/impressions/position for the last 60 days of loop-produced posts. Grade each: climbing / flat / dead. Update `memory.md` — which frames, categories, and cities are winning; which flopped and why (thin demand vs weak angle vs cannibalization). Adjust the frame bank weights and next week's research emphasis accordingly. Flag flat posts 30+ days old for a refresh or a title/H1 experiment.

## Modes

- `daily` (default): research → score → write 3.
- `research-only`: steps 1–2, no writing.
- `write "<topic>"`: skip research, write one specified post to spec.
- `bench`: review the bench, promote up to 3 to today's writes.
- `retro`: weekly retro only.

## Hard rules

- The evergreen gate is absolute: no news, events, openings, or anything that decays inside 24 months — unless deliberately reframed into a durable guide, and then the durable framing is the post.
- Check the content map before every write; never publish a second page targeting a live keyword — refresh the incumbent.
- Every stat carries a date and a source; market numbers come from market-pulse metrics JSONs, never from memory.
- Three posts means three finished posts. If research is thin, say so and write fewer good ones — never pad to quota.
- No two openings in the same week share a structure.
