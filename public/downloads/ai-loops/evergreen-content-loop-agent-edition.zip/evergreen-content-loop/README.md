# Evergreen Content Loop
Daily loop: research SEMrush + YouTube + Search Console -> score candidates (hard evergreen gate, demand, winnability, fit, cannibalization vs your existing posts) -> pick top 5 -> WRITE THE BEST 3 complete publish-ready posts -> weekly GSC retro steers tomorrow's picks. Built to replace decaying news content with pages that compound.
Install: cp -R evergreen-content-loop ~/.codex/skills/
Setup: SEMRUSH_API_KEY in .env, or a recorded browser session, or CSV drops in content-loop/inbox/semrush/. First run builds content-loop/content-map.json from your blog (the cannibalization guard).
Run: "Use $evergreen-content-loop to run today."
