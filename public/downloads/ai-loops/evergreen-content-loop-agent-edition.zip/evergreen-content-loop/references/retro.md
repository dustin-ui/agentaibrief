# Weekly Retro
Inputs: GSC performance (last 60d) for loop posts; content-map dates.
Grade each post: climbing (position improving or clicks up WoW), flat, dead (no impressions after 21d).
Learn: winning frames/categories/cities -> boost frame-bank weights; flopped picks -> classify cause (thin demand / weak angle / cannibalized / not indexed) and note the tell that would have caught it at scoring time.
Actions: reweight frames; queue refreshes for flat 30d+ posts (title/H1 experiment first); append findings + this week's openings list to memory.md; set one experiment for next week with its check date.
