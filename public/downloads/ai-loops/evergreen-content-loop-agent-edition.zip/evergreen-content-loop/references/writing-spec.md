# Writing Spec — publish-ready evergreen posts

Structure:
1. H1 = the query, humanized. Opening paragraph answers it directly in 2–4 sentences (the AI-citable block), then promises the depth below. No throat-clearing.
2. Question H2s mirroring real query phrasings (from research), each section answer-first then detail.
3. Dated stats: market numbers pulled from market-pulse metrics JSONs with pull date in-sentence, linking the city's /housing-market/ page. No number without a date and source.
4. Team voice: at least two passages of practitioner interpretation ("what we tell sellers in {city} about this") that a template couldn't produce.
5. FAQ block: 3–5 real questions, concise answers, FAQPage schema in the HTML variant.
6. Internal links: the relevant city market page, the moving-to guide, one service page, 1–2 sibling posts. Descriptive anchors.
7. CTA matched to intent (seller -> pricing consult; buyer/relocation -> onboarding/guide).
8. Metadata: title <=60 chars, meta description <=155 with the direct answer, slug short and evergreen (no dates in URL).

Rules: 1,200–1,800 words typical, content-first not count-first. Unique opening structure vs this week's posts (check memory.md). Grade-8 readability, short paragraphs, no bullet-spam. Author byline = a named team member. Every claim about process/law stays generic-safe (state/county differences noted, no legal advice).
