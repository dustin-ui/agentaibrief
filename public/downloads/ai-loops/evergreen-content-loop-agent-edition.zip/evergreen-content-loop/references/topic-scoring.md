# Topic Scoring

## Gate first: the evergreen test (pass/fail)
"Will people still search this, roughly as phrased, in 24 months?" Fails: openings, closings, events, incident news, "coming to [city]" development items, anything anchored to a dated occurrence. A news subject may pass ONLY by reframing into the durable question underneath (e.g., development news -> "Living in [city]: what's been built and what it means for home values") — and then the durable frame is the topic.
Year-stamped titles ("...in 2026") pass if the underlying question is durable; the year is a freshness signal to update at refresh, not the substance.

## Score (0–100)
- Demand 30 — volume or GSC impressions; question keywords get +5 (AI-answer surface).
- Winnability 25 — difficulty vs site authority; GSC position 8–30 candidates +10; frames the site already ranks for in sibling cities +5.
- Business fit 20 — seller-intent > relocation-buyer > general local interest. Direct service adjacency scores top.
- Durability margin 15 — beyond the gate: multi-year (school pyramids, taxes, commute) > annually-refreshed (best-of lists).
- Portfolio balance 10 — fills a gap in category/city coverage per the content map; penalize a 4th consecutive post in the same category-week.

## Cannibalization check (before pick, not after)
Match candidate keyword against content-map.json (normalized token overlap + same-intent test). Overlap high -> the pick becomes "refresh <existing URL>" with the candidate angle folded in. Two live pages chasing one keyword split authority and both lose — this rule exists because the site has years of accumulated posts.

## Output
Ranked candidates with per-factor scores, gate results, cannibalization verdicts, and a one-line rationale each. Top 5 presented; top 3 written.
