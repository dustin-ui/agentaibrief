# Research Sources — daily lanes

Same tri-lane pattern as the other loops. Every lane outputs candidate rows: {"keyword","volume","difficulty","trend","source","notes"} (nulls allowed — the scorer handles missing data).

## SEMrush (primary)
- API lane: requires SEMRUSH_API_KEY + API units. Pulls: Keyword Gap vs 2–3 competitor domains, Questions report for seed terms, Keyword Magic for frame x city combos.
- Browser lane: recorded session against the user's logged-in account (persistent profile ~/.content-semrush), exporting the same three reports as CSV.
- Inbox lane: manual CSV exports dropped in content-loop/inbox/semrush/ — a 10-minute VA task.

## Google Search Console (owned goldmine)
Queries with impressions > 200/mo and position 8–30 = demand Google already associates with the site but hasn't rewarded. These candidates get a winnability bonus. API if connected; else a performance export in content-loop/inbox/gsc/.

## YouTube demand
Autocomplete expansions of frame x city seeds, plus evergreen-titled videos in the niche with outsized views relative to channel size (signals unmet search demand). Web-tool research; no login needed. Note high-performing title patterns — they often convert directly into post H1s and later feed the video pipeline.

## Frame bank
data/topic-frames.seed.json holds durable patterns (cost-of-living, best-neighborhoods-for-X, X-vs-Y, property-taxes-explained, commute guides, HOA/condo guides, school-pyramid explainers, senior/downsizing, first-time-buyer by county...). Cross with your market's submarkets for a candidate space in the thousands; the retro reweights which frames get research attention.
