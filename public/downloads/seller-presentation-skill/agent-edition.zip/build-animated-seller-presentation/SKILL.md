---
name: "build-animated-seller-presentation"
description: "Interview the agent once at first run to build a reusable local profile, then build custom animated seller presentations for each listing from that profile plus a short per-listing intake."
---

# Build Animated Seller Presentations

Create a polished, interactive seller presentation from materials supplied by the agent using the skill. Preserve the reusable presentation architecture, animations, calculators, responsive behavior, accessibility, compliance, deployment, and QA methods without bundling any company-specific content.

## Clean-package rule

This skill package must contain no preloaded agent or brokerage branding, logos, brand colors, fonts, listing photos, addresses, presentation pages, videos, client information, CMA records, testimonials, reviews, proprietary claims, or marketing statistics.

The installing agent's own profile, created locally by the setup interview, is the only reusable store. Reuse it freely across that agent's listings. Never copy assets, data, or claims from another agent, another team, or a prior presentation built for anyone else. Never write listing-specific data into the profile.

## Profile system

This skill is personalized at first run, not shipped personalized.

On every invocation, resolve the profile location and check for `profile.json`:

1. `$SELLER_PRESO_HOME` if set
2. `~/.seller-presentation/`
3. `./agent-profile/` in the current workspace

**Profile missing:** run the setup interview in `references/setup-interview.md` before any design or code. The interview collects brand, proof and claims, channels and media, differentiators, a design direction, and delivery defaults in six short steps, then saves `profile.json`, `claims.json`, `style.json`, and `assets/`.

**Profile present:** open with one line stating who the profile is for, when it was last updated, and that "update profile" changes it. Then ask only the per-listing questions below. Never re-run the full interview unless asked or the profile is unreadable.

Support three commands at any time: `update profile` (revisit any interview step, bump `updatedAt`), `show profile` (print a readable summary with claim statuses), and `reset profile` (require explicit confirmation, then delete and re-interview).

The profile lives outside the skill folder so skill upgrades never touch it.

## Per-listing intake

With a valid profile, each new presentation needs only:

- Property address and locality
- Property type, status, approved pricing language, and key features
- Listing photos, video, floor plans, aerials, or renderings
- The seller-facing objective and any facts that must be highlighted
- Any facts or sections that must remain private
- Calculator run values when included: estimated sale price, payoff, concessions
- Section order changes or exclusions for this seller
- Delivery: local-only, shareable preview, or public; access policy; existing hosting project ID

Ask in one concise, organized message. Summarize what was received and what is missing, then wait for confirmation unless the agent explicitly directs you to proceed with clearly labeled placeholders.

Read `references/intake-and-claims.md` for the per-listing record and the claim and asset ledgers.

## Core outcome

Produce a mobile-first guided presentation that helps a seller understand:

1. The listing opportunity and positioning
2. The agent's distinct value proposition
3. The marketing reach and channel strategy
4. The launch, communication, and reporting plan
5. Estimated seller proceeds when requested
6. Proof of service, execution, and results
7. The next step

The result must feel like a premium guided experience, not a pasted PDF or generic landing page.

## Source and asset audit

1. Record every supplied file and stable source URL.
2. Maintain the asset ledger with owner/source, intended use, crop rules, and alt text.
3. Maintain the claim ledger with exact display wording, type, source, date, conditions, caveat, and status. Profile claims arrive pre-recorded in `claims.json`; verify status before display. Claims raised during a listing run go through the same ledger before use.
4. Confirm that the user is authorized to use logos, photos, videos, reviews, and reports.
5. Extract presentation pages as individual images only when they add persuasive proof or visual explanation.
6. Confirm the brand system and listing facts before writing UI code.
7. Remove unsupported or unapproved material instead of filling gaps with another company's content.

## Information architecture

Choose and order sections based on the profile and listing intake. A strong default is:

- Opening and listing opportunity
- Property story and positioning
- Agent or team advantage
- Marketing reach comparison
- Marketing channels
- Side-scrolling presentation gallery
- Listing-video examples
- Launch and communication plan
- Seller proceeds calculator when requested
- Reviews, credentials, proof, and next step

Keep persistent navigation compact. Each section should answer one seller question and lead naturally to the next.

## Design system

Every presentation is built from a named design direction plus the agent's brand tokens. Read `references/design-directions.md` before proposing or implementing any design.

1. Apply the direction stored in `style.json`. If none exists, present the named directions with a one-line fit note each, build a style tile for the chosen one, and store the approval.
2. Derive CSS variables for color roles, fluid type scale, spacing, radius, shadow, and motion from the direction plus the supplied brand assets. Never scatter raw hex values through components.
3. Use only the current agent's approved logos, colors, fonts, photography, and disclosures.
4. Run the contrast procedure on every brand color pair used for text and store approved accessible pairs in `style.json`.
5. Use one display type family and one highly readable text family unless the brand guide requires otherwise. Set `font-variant-numeric: tabular-nums` on every animated or aligned numeral.
6. Use large numerals, editorial spacing, numbered section kickers, premium media treatment, and strong contrast.
7. Collapse any section whose data is missing. Never render placeholder content in a final build.
8. Keep identity visible without turning every section into an advertisement.
9. Never fabricate a logo, team photo, award, credential, review, or brand claim.
10. Support 390px mobile, tablet, and desktop layouts. Honor `prefers-reduced-motion`.

Read `references/motion-and-layout.md` before implementing motion.

## Motion system

Use motion to explain and focus attention:

- Animate important numbers only when they enter the viewport, in tabular figures with one consistent number format.
- Compare typical reach with the agent's verified reach using counters and proportionate visual bars.
- Use staggered reveal motion for cards and proof points.
- Use a restrained looping ticker for marketing channels.
- Use horizontal scroll snapping for presentation-page galleries on touch devices.
- Use side-scrolling or sticky storytelling only when it stays predictable on mobile.
- Add subtle parallax or tilt only to decorative media, never form controls.
- Use visible foreground motion such as sliding cards, animated headlines, moving progress elements, or changing counters when animation is meant to be a focal feature.
- Load video embeds through poster-frame facades activated by the user.
- Avoid auto-playing audio.
- Pause or simplify looping effects when reduced motion is requested.

All animations must be deterministic from page state, free of layout shift, and safe when the user scrolls backward or reloads mid-page.

## Marketing reach comparison

When the profile supplies a comparison between typical listing exposure and the agent's own reach:

1. Verify the wording and source against the claim ledger.
2. Label it as a guarantee, historical average, target, or example.
3. Animate the values only after the section enters view.
4. Animate the corresponding bars or visual scale with the counters.
5. When the featured value exceeds typical by roughly 8x or more, cap the drawn bar ratio near 8:1 and print the true multiple as text. Unreadable slivers persuade no one.
6. Put the caveat in the same section.
7. State that actual delivery and response vary by property, market, creative, platform, budget, and campaign.
8. Never imply that views guarantee offers, price, or sale timing.

Do not include a default reach number. The current agent must provide and support it.

## Marketing channel story

Translate the agent's supplied materials into channel modules. Possible modules include:

- Professional photography, floor plans, aerials, staging, and visual preparation
- Story-led or high-production property films
- YouTube and connected-TV distribution
- Fair-housing-compliant paid social advertising
- Database and email marketing
- Agent-to-agent distribution
- Open-house and launch strategy
- Print or direct-mail support
- Weekly performance reporting

Only show channels the agent actually uses or explicitly plans to use. Use presentation pages as a side-scrolling proof gallery. Embed videos only from approved URLs, use privacy-enhanced embeds behind poster facades where supported, and provide meaningful accessible titles.

## Seller proceeds calculator

Include only when requested. Treat the calculator as a centerpiece, not a form. Build a client-side calculator with editable inputs for:

- Estimated sale price
- Listing-side commission percentage or amount
- Buyer-agent compensation percentage or amount
- Estimated seller closing costs
- Mortgage or lien payoff
- Seller concessions
- Other expenses

Calculate each deduction and estimated net proceeds instantly. Animate the net-proceeds numeral on every input change and render a proceeds waterfall from sale price through each deduction to net. Style controls with the accent role. Format currency clearly and keep calculations local unless storage is explicitly requested.

Percentage ranges and closing-cost assumptions come from the profile's calculator defaults. Sale price, payoff, and concessions come from the listing run.

Required disclaimers:

- All amounts are estimates.
- Commission and buyer-agent compensation are negotiable.
- Compensation is not set by law or by an MLS.
- Historical compensation data does not prescribe a future offer.
- Taxes, prorations, title charges, payoff, and settlement figures must be confirmed with the appropriate professionals.

Never prefill another agent's percentages, transaction statistics, or historical compensation data.

## Fair Housing and advertising compliance

Describe property and marketing features, not preferred buyers or protected classes. Do not target or describe audiences using protected characteristics. When discussing paid social distribution, use compliant wording such as permitted geography, platform-approved audience settings, creative, reach, and reporting.

Do not use language such as family-friendly, perfect for families, ideal for singles, young professionals, retirees, exclusive neighborhood, or religious, racial, ethnic, disability, gender, or age-based targeting language.

## Implementation

Use the host project's existing framework when one exists. For a new project, prefer a modern React or Next-compatible static or server-rendered site with:

- A single data layer split into the persistent agent profile and the per-listing data, composed at build time
- Empty arrays or null values for materials the user has not supplied
- Semantic section landmarks and keyboard-accessible navigation
- CSS variables for color roles, spacing, typography, radius, shadow, and motion
- IntersectionObserver for entry-triggered counters and reveals
- Native horizontal overflow and scroll snapping for galleries
- Responsive images with fixed intrinsic dimensions and blur-up or dominant-color placeholders
- Preloaded display font with `font-display: swap`
- No external runtime dependency for basic animation unless it materially improves the result

Use `templates/agent-profile.ts` and `templates/listing-data.ts` as the neutral data-model starting points, composed by `templates/presentation-data.ts`. Keep content out of deeply nested JSX so another agent can update it safely.

## Validation gate

Before handoff:

1. Run lint and production build.
2. Verify every logo, image, presentation page, and video loads.
3. Verify all links and section navigation.
4. Verify calculator math with at least three test cases when included.
5. Verify counters and reveals trigger once and end on the correct values.
6. Verify the reach comparison labels and caveats match the claim ledger.
7. Verify reduced-motion behavior.
8. Verify desktop and 390px mobile with no horizontal page overflow.
9. Verify gallery scrolling remains intentional and does not trap the page.
10. Verify text contrast, keyboard focus, and accessible labels.
11. Review every numerical or comparative claim against its source.
12. Review compensation and proceeds disclaimers when applicable.
13. Confirm the configured access policy matches the user's intent.
14. Preserve an existing hosting project ID when updating a deployed presentation.
15. Confirm the project contains no asset or data from another agent or listing.
16. Confirm no listing data was written into the profile and no profile field changed without an explicit `update profile`.
17. Confirm the applied tokens match `style.json` and every text/background pair uses a stored approved contrast pair.
18. Confirm animated counters use tabular figures and produce no width jitter.

Use one focused verification pass and one targeted fix pass for objective failures. Stop and report any remaining blocker instead of looping indefinitely.

## Deliverables

Return:

- The editable project folder
- The deployed presentation URL when deployment is requested
- The claim/source ledger
- The replaceable brand, listing, presentation, and media inventory
- Any profile files touched, with their updated timestamps
- Build and QA results
- Any unresolved limitations
- When requested, a print stylesheet or exported leave-behind PDF of the core sections

Never report the presentation complete if required media is broken, calculator math is wrong, unsupported claims remain, or another agent's assets are present.
