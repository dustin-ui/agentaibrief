// Persistent, agent-level data. Created by the setup interview, reused across
// listings, edited only via `update profile`. Never contains listing data.

export type ClaimRef = string;

export type AgentProfile = {
  meta: {
    schemaVersion: 3;
    updatedAt: string; // ISO date
  };
  brand: {
    agentOrTeam: string;
    brokerage?: string;
    primaryLogo?: string;
    alternateLogo?: string;
    logoAlt?: string;
    colors?: { primary?: string; secondary?: string; [role: string]: string | undefined };
    fonts?: { display?: string; body?: string };
    tagline?: string;
    photos?: string[];
    contactUrl?: string;
    socials?: string[];
    disclosures: string[];
  };
  uniqueSellingPropositions: Array<{
    title: string;
    description: string;
    proof?: string;
    claimId?: ClaimRef;
  }>;
  reachComparison?: {
    typicalLow: number;
    typicalHigh: number;
    featuredValue: number;
    featuredSuffix?: string;
    featuredType: "historical" | "target" | "guarantee" | "example";
    source: string;
    sourceDate?: string;
    caveat: string;
    claimId?: ClaimRef;
  };
  marketingChannels: Array<{
    title: string;
    description: string;
    proof?: string;
  }>;
  presentationPages: Array<{
    src: string;
    alt: string;
    title: string;
    label?: string;
  }>;
  videos: Array<{
    provider: "youtube" | "vimeo" | "other";
    idOrUrl: string;
    title: string;
    label?: string;
  }>;
  proof: Array<{
    quoteOrClaim: string;
    source: string;
    sourceDate?: string;
    paraphrased?: boolean;
    claimId?: ClaimRef;
  }>;
  calculatorDefaults?: {
    listingPct: { min: number; max: number; step: number; initial: number };
    buyerPct: { min: number; max: number; step: number; initial: number };
    closingPct: { min: number; max: number; step: number; initial: number };
    disclaimers: string[];
  };
  style: {
    direction: "editorial-estate" | "modern-broker" | "cinema-dark" | "warm-minimal";
    tokenOverrides?: Record<string, string>;
    approvedContrastPairs?: Array<{ fg: string; bg: string; usage: string }>;
  };
  defaults?: {
    cta?: string;
    hosting?: "local" | "preview" | "public";
    access?: "public" | "restricted";
    projectId?: string;
  };
};
