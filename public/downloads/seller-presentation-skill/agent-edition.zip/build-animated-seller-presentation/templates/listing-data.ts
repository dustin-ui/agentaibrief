// Per-listing data. Collected fresh for every presentation run and stored
// with the project. Never written back into the agent profile.

export type ListingData = {
  listing: {
    address?: string;
    locality?: string;
    propertyType?: string;
    status?: string;
    approvedPricingLanguage?: string;
    heroImage?: string;
    heroAlt?: string;
    positioning?: string;
    keyFeatures: string[];
    media?: Array<{
      src: string;
      alt: string;
      kind: "photo" | "floorplan" | "aerial" | "rendering" | "video-poster";
    }>;
    privateFacts?: string[];
    sellerObjective?: string;
  };
  sections?: {
    order?: string[];
    exclude?: string[];
  };
  calculatorRun?: {
    salePrice: number;
    payoff: number;
    concessions: number;
    otherCosts: number;
  };
  delivery?: {
    hosting: "local" | "preview" | "public";
    access?: "public" | "restricted";
    projectId?: string;
  };
};
