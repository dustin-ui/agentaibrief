// Runtime input for a presentation build: the persistent agent profile plus
// one listing run, composed at build time. The merge is one-directional —
// profile data flows into the presentation; listing data never flows back
// into the profile.

import type { AgentProfile } from "./agent-profile";
import type { ListingData } from "./listing-data";

export type PresentationData = {
  profile: AgentProfile;
  listing: ListingData;
};
