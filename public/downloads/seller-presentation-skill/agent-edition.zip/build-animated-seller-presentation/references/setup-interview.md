# Setup interview

Run once per agent, at the first invocation after install. The goal is a reusable local profile so every future listing run starts warm and asks only listing questions.

## Storage

Resolve the profile home in order: `$SELLER_PRESO_HOME`, `~/.seller-presentation/`, `./agent-profile/` in the workspace. Offer the choice during step 1 and record it. Create:

- `profile.json` — brand, contact, disclosures, USPs, channels, videos, presentation pages, proof, reach claim, calculator defaults, delivery defaults, `meta.schemaVersion`, `meta.updatedAt`
- `claims.json` — the claim ledger defined in `intake-and-claims.md`
- `style.json` — chosen design direction, token overrides, approved contrast pairs
- `assets/` — logos, headshots, presentation-page images the agent supplies

Never store listing addresses, listing media, seller information, or CMA data in the profile.

## Fast path

Offer first: "Paste your website or an existing listing-presentation URL and I'll draft your profile for you to correct." Everything extracted is a draft. Mark every extracted numerical or comparative claim `pending` in `claims.json` and confirm each one explicitly before display. Never promote a scraped number to verified.

## Steps

One message per step. Show progress ("Step 2 of 6"). Accept "skip" on any item and record it as intentionally omitted or awaiting approval. Keep each message short enough to answer from a phone.

1. **Brand.** Agent, team, and brokerage names; primary and alternate logos; brand colors and fonts; tagline and approved brand language; agent or team photos; contact details, website, socials; required brokerage disclosures; any brand guide or design references; storage location choice.
2. **Proof and claims.** Review totals, credentials, awards, results, case studies, reach or audience numbers, database size, guarantees. For every number: source, date, conditions, claim type, and approved caveat.
3. **Channels and media.** Approved marketing channels; production process; reporting cadence; approved YouTube, Vimeo, or other video URLs; campaign examples; presentation pages to reuse as gallery proof.
4. **Differentiators.** Service promises; negotiation, operations, staging, pricing, or launch advantages; communication standards; anything they are authorized to display that competitors cannot match.
5. **Design direction.** Present the directions from `design-directions.md` with a one-line fit note each. Take brand colors, run the contrast procedure, and resolve failures with approved tints. Build a single-file style tile — hero sample, type specimen, color roles, a button, one animated counter — and get approval before saving `style.json`.
6. **Delivery defaults.** Calculator include or omit, default percentage ranges and closing-cost assumption, default call to action, default hosting mode and access policy, existing hosting project ID if any.

## Close

Print a profile summary: what was captured, claim statuses, and omissions. Get one confirmation, then save all files and state where they live and how to change them. Do not begin a listing build inside the interview; end by asking for the first listing when the agent is ready.

## Maintenance

- `update profile` jumps to any step, edits it, and bumps `updatedAt`.
- When `updatedAt` is older than 90 days, ask one line at run start: "Profile last updated {date} — still current?"
- `reset profile` requires explicit confirmation, then deletes the profile home and re-runs the interview.
- On a `schemaVersion` mismatch after a skill upgrade, migrate additively. Never drop verified claims or approved contrast pairs silently.
