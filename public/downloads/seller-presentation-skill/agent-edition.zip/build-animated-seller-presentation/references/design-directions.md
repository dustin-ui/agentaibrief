# Design directions

Pick one direction per agent during setup and store it in `style.json`. Directions are token sets, not hard-coded themes: the agent's brand colors map onto the roles below. Never blend directions; pick one and let brand tokens differentiate.

## Shared craft rules

- Color roles: `--bg`, `--surface`, `--ink`, `--muted`, `--accent`, `--on-accent`. Map brand colors to roles once; components reference roles only.
- Fluid type with `clamp()`: display around `clamp(2.5rem, 6vw, 5rem)`, section titles around `clamp(1.75rem, 3.5vw, 2.75rem)`, body 1rem to 1.125rem. Maximum line length near 70ch.
- Section kickers: uppercase labels, letter-spacing 0.08–0.12em, muted color, with a two-digit chapter number (01, 02, ...) above every section title.
- Numerals: `font-variant-numeric: tabular-nums` wherever a number animates or aligns. Choose one formatting style (compact "1.2M" or full "1,200,000") and use it everywhere.
- Rhythm: alternate band treatments between sections, spacing from a 4/8px scale, one idea per viewport on mobile.
- Hero: full-bleed listing media with a gradient scrim and the address in display type when media exists; brand-led hero otherwise. Slow Ken Burns scale on the media hero, static under reduced motion. Visible scroll cue.
- Images: reserve space with `aspect-ratio`, use blur-up or dominant-color placeholders, keep crops consistent within a section, never stretch a logo.
- Video: poster-frame facade that loads the privacy-enhanced embed on activation, keyboard-accessible, labeled with the video title.
- Fonts: preload the display face, `font-display: swap`, subset when self-hosting.
- Interactive states: visible hover, press, and `:focus-visible` styles in the accent role.
- Empty states: a section with no data does not render.

## Contrast procedure

For every text/background pair drawn from brand colors, check WCAG AA (4.5:1 body, 3:1 large text). On failure, generate the nearest accessible tint or shade, show it beside the original, and get approval. Store approved pairs in `style.json` and use only those pairs in code.

## Editorial Estate

High-serif display over quiet neutrals. Reads like a magazine feature about the property.

- Type: serif display (Fraunces or Playfair class) with a humanist sans for text
- Surfaces: ivory or warm paper background, ink text, hairline rules
- Radius 0–4px, near-zero shadows, texture from rules and generous whitespace
- Motion personality: slow and settled, long ease-outs
- Best for: luxury, estates, historic, and design-led listings

## Modern Broker

Confident grotesk system with oversized numerals. Reads like a sharp operating company.

- Type: grotesk sans (Inter or Sohne class) for both roles, contrast through weight
- Surfaces: white and near-black bands, accent used sparingly
- Radius 4–8px, crisp small shadows
- Motion personality: quick and precise; the counters are the show
- Best for: teams selling process, reach, and metrics

## Cinema Dark

Dark, media-forward, film-credit typography. The presentation plays like a trailer.

- Type: tight sans display with a readable sans for text, lighter weights on dark
- Surfaces: near-black background, elevated dark surfaces, one luminous accent
- Radius 8–12px, glow-tinted shadows on media only
- Motion personality: cinematic reveals, slightly longer durations
- Best for: agents with strong property-film assets; run the contrast procedure carefully

## Warm Minimal

Soft neutrals, rounded geometry, airy spacing. Approachable premium.

- Type: rounded or humanist sans display with same-family text
- Surfaces: warm off-whites with gentle sand or clay tints, large-radius cards
- Radius 16–24px, diffuse low shadows
- Motion personality: gentle fades and small rises
- Best for: suburban and lifestyle listings and approachable price points

## Choosing

If the agent has a brand guide, map it onto the nearest direction and note deviations. If not, recommend one from their assets and market position, show the style tile, and let them redirect. Approval of the style tile is the gate before any full build.
