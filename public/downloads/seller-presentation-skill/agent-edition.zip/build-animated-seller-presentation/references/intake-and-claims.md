# Per-listing intake and ledgers

Agent-level material lives in the profile and is captured by the setup interview. This file covers what each listing run records and how claims and assets are tracked.

## Per-listing intake record

Record for each presentation run:

- Listing: address and locality, property type, status, approved pricing language, key features, property media, privacy restrictions, and seller objective
- Presentation: section order changes, exclusions, rewrite requests, preferred length, and meeting format
- Calculator run: estimated sale price, payoff, and concessions when the calculator is included
- Hosting: local-only or deployed, public or restricted access, and existing project ID or new project

Mark every missing item as required, optional, intentionally omitted, or awaiting approval. Listing records live with the project, never in the profile.

## Claim ledger

For every numerical or comparative claim, record:

| Field | Meaning |
|---|---|
| Claim ID | Stable short identifier |
| Display wording | Exact seller-facing copy |
| Claim type | Historical, current, target, guarantee, estimate, or example |
| Source | File, URL, report, or approved user statement |
| Source date | Date or reporting period |
| Conditions | Property type, budget, geography, platform, or other qualifiers |
| Caveat | Required limitation shown near the claim |
| Status | Verified, user-approved, pending, softened, removed |

Claims captured at setup live in the profile `claims.json`. Claims raised during a listing run are added there only if they are agent-level and reusable; listing-specific claims stay with the project. Never display a claim whose status is pending.

## Asset ledger

For every asset, record file or URL, owner/source, permission, intended section, crop rules, and alt text.

Never package one agent's logo, colors, listing data, address, media, private reports, reviews, testimonials, claims, or statistics into a skill or project intended for another agent.
