# Motion and layout patterns

## Viewport counter

Use IntersectionObserver and disconnect after the first successful run. Animate with `requestAnimationFrame`, an ease-out curve, and a fixed duration. Set `font-variant-numeric: tabular-nums` so digits do not shift width mid-animation, and use one number format everywhere. If reduced motion is active, show the final value immediately.

## Reveal system

Give revealable elements a default opacity and transform state, then add one visible class from IntersectionObserver. Avoid delays longer than one second. Do not hide essential content if JavaScript fails.

## Reach comparison

Use two cards or bars with visibly different scale. Animate the numbers and the larger bar together. When the featured value exceeds typical by roughly 8x or more, cap the drawn ratio near 8:1 and print the true multiple as text. Label historical, typical, target, example, or guarantee status directly. Put the caveat in the same section.

## Channel ticker

Duplicate a short list of approved channel labels to create a seamless CSS loop. Treat it as decorative, keep it out of the tab order, and stop the animation for reduced motion.

## Presentation gallery

Use `display:grid` or `display:flex`, `overflow-x:auto`, and `scroll-snap-type:inline mandatory`. Each page should have a title, category label, intrinsic dimensions, and mobile width near 85vw. Let the next card peek at the edge, add soft edge-fade masks, show a "3 / 12" position counter, and support arrow-key navigation. Do not use a carousel that traps swipe or keyboard navigation.

## Side-scrolling story

Use horizontal progression for short, strongly related proof cards or presentation pages. Preserve native touch scrolling and expose a visible progress cue. Provide a normal vertical fallback when the viewport is narrow or reduced motion is enabled.

## Sticky story

Use sticky positioning only above a minimum viewport width. On mobile, return to normal document flow. Never make the entire page scroll inside a nested container.

## Video facade

Render a poster image with a play affordance and load the privacy-enhanced iframe only on activation. Make the facade keyboard-activatable and label it with the video title. This keeps initial load fast and avoids third-party requests before consent.

## Ken Burns hero

A single slow scale (about 1.0 to 1.06 over 12–20 seconds) on the hero media only, paused under reduced motion. Never pan or scale text.

## Scroll progress

A 2–3px top progress bar driven by scroll position is enough. Do not add scroll hijacking.

## Hover depth

Restrict tilt or parallax to pointer-capable devices. Reset on pointer leave. Do not apply it to sliders, inputs, buttons, or text-heavy cards.

## Proceeds waterfall

Render sale price as the full bar, subtract each deduction as a labeled segment, and end on the net figure. Animate segment widths and the net numeral together on input change, under 300ms, with no layout shift. Keep the disclaimers in the same section.

## Reduced motion

Under `@media (prefers-reduced-motion: reduce)`, disable smooth scrolling, long transforms, parallax, infinite loops, Ken Burns, and transition delays. Keep state changes understandable.
