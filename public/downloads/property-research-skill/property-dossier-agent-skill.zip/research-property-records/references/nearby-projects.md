# Nearby construction and development research

## Contents

1. Define the screen
2. Discover projects
3. Verify status and timing
4. Evaluate possible impacts
5. Report the evidence

## 1. Define the screen

Use a default near-term horizon of active work plus the next 36 months. Also inspect longer-range plans for major projects, but place unfunded or unscheduled items in a watchlist.

Choose a search area based on development pattern and project scale:

| Setting | Search all discrete projects | Search regionally significant projects |
|---|---:|---:|
| Dense urban | 0.5–1 mile | 3 miles |
| Suburban | 1–2 miles | 5 miles |
| Rural | 3 miles | 10 miles |

Adapt the radius to terrain, access patterns, parcel size, and project type. Expand beyond the circle along the property's principal access route, evacuation route, watershed, viewshed, or utility corridor when relevant. State the chosen scope in the report.

Regionally significant projects include major road or bridge work, transit, airports, rail, large residential subdivisions, hospitals, schools, warehouses, distribution centers, data centers, power generation or transmission, utility plants, mines, quarries, landfills, waste facilities, and large renewable-energy projects.

## 2. Discover projects

Search every authority that overlaps the study area. Start with official maps and case portals, then search agendas and documents that may not appear on maps.

### Local land-use sources

- Active development or development-pipeline map
- Planning, zoning, subdivision, and site-plan case portal
- Rezoning, annexation, comprehensive-plan amendment, variance, conditional-use, and special-use cases
- Planning commission, zoning board, council, and county-board agendas, minutes, staff reports, and hearing notices
- Building, demolition, grading, erosion-control, and land-disturbance permits
- Public notice pages and posted-property notices when indexed online
- Capital-improvement program and adopted budget
- Public works, parks, schools, and facilities project pages

### Transportation and infrastructure sources

- State or provincial transportation project map
- Metropolitan planning organization transportation-improvement program
- Local road, bridge, sidewalk, trail, signal, and streetscape programs
- Transit authority capital plans and service changes
- Water, sewer, stormwater, drainage, flood-control, and solid-waste capital projects
- Electric, gas, pipeline, and transmission planning or siting cases
- Broadband and communications infrastructure projects
- Airport, port, rail, and military planning notices where relevant
- Contract awards, bid notices, construction notices, lane-closure notices, and utility shutdown notices

### Search tactics

- Search the subject street and every bordering street.
- Search adjacent parcel identifiers and nearby named developments.
- Search the municipality, county-equivalent, neighboring municipality, state or province, transportation agency, planning organization, utilities, and special districts.
- Search project names discovered in agendas across later agendas, permits, contracts, and agency updates.
- Search recent documents by year and the terms `construction`, `site plan`, `subdivision`, `rezoning`, `grading`, `capital project`, `contract award`, `notice to proceed`, and local equivalents.
- Inspect official maps spatially; address-only text searches miss projects on vacant land.

Do not rely on a developer's marketing page as proof of approval or schedule. Use it only as a lead or as the developer's stated plan, clearly labeled.

## 3. Verify status and timing

Assign the strongest status supported by current evidence:

| Status | Minimum supporting evidence |
|---|---|
| Under construction | Official construction update, notice, inspection activity, or current official project page |
| Awarded/funded/scheduled | Awarded contract, adopted funded program, notice to proceed, or published construction schedule |
| Permit issued | Current building, grading, demolition, or land-disturbance permit authorizing work |
| Approved | Final decision, adopted ordinance, signed plan, or recorded approval; no work authorization located |
| Pending | Active application or scheduled hearing without final approval |
| Conceptual/long-range | Study, comprehensive plan, unfunded program, or early proposal |
| Completed/cancelled | Official completion, withdrawal, denial, expiration, or cancellation |

For each project, seek at least two official evidence points when possible: one for entitlement or funding and one for the latest implementation status. Capture the latest status date. If sources conflict, report the conflict and prefer the agency controlling the relevant approval or work.

Do not convert an approval expiration date into a construction date. Do not assume a funded project will start on time. Quote no more than necessary; link the controlling document.

## 4. Evaluate possible impacts

Record objective facts first: project type, size, site, distance, direction, access points, approved conditions, phasing, work hours, and published schedule.

Then identify plausible impact channels:

- Traffic volume, turn movements, construction vehicles, lane closures, and detours
- Noise, vibration, dust, blasting, lighting, and construction hours
- Changes to access, parking, sidewalks, trails, transit, or emergency routes
- Views, privacy, tree removal, buffers, height, and nighttime lighting
- Grading, drainage, stormwater, floodplain, wetlands, and downstream effects
- Water, sewer, electric, gas, broadband, or other service changes
- School, park, emergency-service, or public-facility capacity
- New amenities, connectivity, services, or public improvements

Call these "potential impact channels" unless an official traffic, environmental, drainage, noise, or fiscal study supports a firmer statement. Cite the study and distinguish its conclusions from inference. Never predict appreciation, depreciation, marketability, or health effects.

## 5. Report the evidence

Create a nearby-projects table with these fields:

```text
Project ID
Project name
Project type
Location
Distance and direction from subject
Controlling jurisdiction or agency
Current status
Latest official status date
Published construction window
Scale or scope
Potential impact channels
Confidence
Primary source IDs
Notes and unresolved questions
```

Use confidence labels:

- High: current controlling record plus corroborating implementation evidence
- Medium: current controlling record but schedule or implementation remains uncertain
- Low: incomplete, stale, conflicting, or noncontrolling evidence

Put active, awarded, scheduled, and permitted work in the main near-term section. Put approved-but-unpermitted work in a separate approved section. Put pending and conceptual items in the watchlist. Put completed, cancelled, or clearly irrelevant results in the source index so the search remains auditable without cluttering the executive summary.
