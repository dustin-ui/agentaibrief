# Property records research matrix

## Contents

1. Search discipline
2. Property identity and land records
3. Improvements, permits, and legal use
4. Water, wastewater, and utilities
5. Site conditions and hazards
6. Restrictions, obligations, and operating records
7. Records that usually require the owner or a professional

## 1. Search discipline

Search every relevant portal using several identifiers because public indexes are inconsistent:

- Exact street address and common variants
- Parcel, assessment, folio, or account number
- Map, block, lot, section, subdivision, and unit
- Deed book and page, instrument, liber and folio, or title identifier
- Current owner and prior owner only where the portal requires a party name
- Permit, case, plan, or project number discovered in another record

Record both positive and negative searches in `source-index.csv`. For a negative search, describe the identifiers used, the portal coverage dates when stated, and any indexing limitation.

Verify that documents match the subject parcel. Shared street numbers, renamed roads, parcel splits, consolidations, condominium units, and mailing-city names often cause false matches.

## 2. Property identity and land records

| Topic | Preferred official source | Capture | Common issue |
|---|---|---|---|
| Parcel identity | Assessor, cadastre, tax authority, land registry | Parcel ID, situs address, owner, land area, use class | Mailing address differs from situs or jurisdiction |
| Assessment facts | Assessor or tax card | Year built, living area, buildings, bedrooms where shown | Assessment data does not legalize improvements |
| Tax status | Tax collector or treasurer | Current balance, delinquency, exemptions, special charges | Recent payments may not yet post |
| Deed | Recorder, clerk, registry, titles office | Grantee, legal description, recording data, referenced documents | Index entry alone may omit restrictions |
| Plat or survey plan | Recorder, survey-plan registry, planning department | Boundaries, dimensions, easements, setbacks, common areas | Parcel GIS is not a boundary survey |
| Recorded easements | Recorder or registry | Access, utilities, drainage, conservation, shared facilities | Easement exhibit may be a separate document |
| Covenants and declarations | Recorder, registry, association filing | Use limits, maintenance duties, architectural rules | Later amendments can supersede originals |
| Liens tied to the real estate | Recorder, tax authority, statutory registry | Instrument and status | Do not present a web search as a title examination |
| Solar or energy obligations | Recorded instruments plus seller documents | Lease, power-purchase agreement, financing or assessment | Transfer or payoff terms are often nonpublic |
| Ground, mineral, timber, or water rights | Deed and specialty registries where applicable | Reservations, severances, leases | Local law and indexing vary widely |

## 3. Improvements, permits, and legal use

Search the authority with jurisdiction on the work date; annexations and agency changes matter.

| Topic | Preferred official source | Capture | High-value check |
|---|---|---|---|
| Building permits | Permit and inspection department | Scope, contractor, issue date, status, valuation | Addition, garage, deck, porch, shed, roof |
| Trade permits | Electrical, plumbing, mechanical, gas portals | Scope and final status | Work may exist under a separate permit |
| Occupancy approval | Building or fire authority | Certificate of occupancy, use approval, final inspection | New dwelling, addition, conversion, ADU |
| Open or expired permits | Permit authority | Last inspection, correction notice, expiration | A permit number is not proof of completion |
| Code enforcement | Code, housing, nuisance, fire, zoning authority | Open cases, orders, compliance status | Cases may be indexed by parcel or owner |
| Assessor-building comparison | Assessor, permits, official aerials | Footprint and improvement timeline | Detect undocumented additions or outbuildings |
| Zoning | Planning or zoning authority | District, overlay, current code map date | Do not rely only on a portal's summary label |
| Legal use | Zoning and occupancy records | Dwelling type, unit count, ADU, home occupation | Existing use may be nonconforming or unauthorized |
| Development rights | Planning authority | Setbacks, lot coverage, density, frontage | Refer buildability conclusions to the agency |
| Variances and special approvals | Board of appeals, planning commission | Decision, conditions, expiration | Approval may run with land or require action |
| Rental or lodging license | Housing, licensing, tourism authority | License, inspection, expiration | Include long-term and short-term rental regimes |
| Lead or safety registration | Health or housing authority | Registration or certificate when public | Rules vary by property age and occupancy |

Search individually for common improvements: finished basement, bedroom, bathroom, addition, deck, patio cover, pool, spa, fence, retaining wall, garage, carport, shed, accessory dwelling, fireplace, chimney, generator, solar, battery, roof, septic, well, electrical service, HVAC, plumbing, gas, grading, demolition, fire protection, and occupancy.

## 4. Water, wastewater, and utilities

| Topic | Preferred official source | Capture | High-value check |
|---|---|---|---|
| Water service | Utility or health authority | Public/private status, meter or connection, service area | Availability does not prove a physical connection |
| Private well | Health or water-resources authority | Permit, log, completion, depth, yield, location | Test results and repairs may be owner-held |
| Abandoned wells | Health or water-resources authority | Sealing or abandonment record | Unsealed wells can create safety and contamination issues |
| Sewer service | Utility or wastewater authority | Connection, service area, capacity constraints | Check pending extension and mandatory hookup rules |
| Septic permit | Environmental health or wastewater authority | Design, installation, tank, system type | Verify the exact parcel and approved use |
| Septic capacity | Environmental health authority | Approved bedrooms, daily flow, design capacity | Marketing bedroom count may conflict |
| Perc and reserve area | Environmental health or planning authority | Test results, drainfield and replacement area | Improvements may encroach on reserve area |
| Septic repairs and operating permits | Environmental health authority | Repair history, advanced-treatment obligations | Maintenance agreement or inspection may be required |
| Utility assessments | Utility, treasurer, special district | Connection charges, benefit assessments, arrears | Some charges transfer with the property |
| Electric and gas | Regulated utility or service map | Provider and service availability | Seller bills best establish actual service and cost |
| Broadband | National regulator, state map, provider qualification | Reported technology and availability | Reported availability is not guaranteed installation |

## 5. Site conditions and hazards

Use national sources plus state, provincial, regional, and local layers. Local regulatory maps may be more precise.

| Topic | Preferred official source | Capture | Limitation |
|---|---|---|---|
| Flood hazard | National flood authority and local floodplain office | Effective zone, floodway, elevation, map-change letters | Map status does not reveal every past flood or claim |
| Wetlands and waters | National inventory plus regulatory agency | Mapped wetland, stream, buffer, data date | Inventory mapping is not a jurisdictional delineation |
| Soils | National or state soil survey | Hydric rating, drainage, slope, septic and building limits | Screening does not replace field testing |
| Topography and drainage | Local GIS, survey, elevation agency | Contours, drainageways, stormwater facilities | Parcel-scale accuracy varies |
| Coastal and erosion zones | Coastal authority | Critical area, shoreline, erosion, sea-level overlays | Confirm regulatory boundary with the agency |
| Wildfire | State or national fire authority | Hazard zone, defensible-space or building rules | Hazard models and insurance criteria differ |
| Landslide, subsidence, mine, or karst | Geological survey and local authority | Susceptibility, mine workings, sinkholes | Maps may be regional rather than parcel-specific |
| Radon | Health or environmental authority | Regional potential and available test data | Test the individual structure; maps cannot clear it |
| Dam or levee inundation | Emergency-management or dam-safety authority | Inundation or evacuation zone | Some security-sensitive detail may be withheld |
| Pipelines and transmission | Pipeline regulator and utility planning | Approximate corridor and operator | Public maps may intentionally limit precision |
| Contaminated sites | Environmental agency | Cleanup program, status, case documents | Absence from a map is not an environmental clearance |
| Tanks and releases | Environmental agency or fire marshal | Registered tanks, leaking tanks, closure | Residential heating tanks may not be comprehensively indexed |
| Brownfields and former uses | Environmental and planning agencies, historic official maps | Program records, prior land use | Refer material concerns to an environmental professional |
| Noise or compatibility overlays | Airport, military, rail, highway, or local planning authority | Noise contour or compatibility district | Actual conditions vary over time |

## 6. Restrictions, obligations, and operating records

| Topic | Preferred official source | Capture | Follow-up |
|---|---|---|---|
| Historic status | Preservation authority and local district | Listing, district, easement, review rules | Inventory listing and legal restriction are not always the same |
| Agricultural or conservation program | Land, agriculture, or conservation authority | Easement, program term, development limits | Ask about rollback or transfer charges |
| Forest or open-space restriction | Planning, conservation, recorder | Recorded plan, maintenance obligation | Map exhibit may control |
| Road ownership | Roads, public works, transportation agency | Public/private status, maintenance authority | A postal address does not establish legal access |
| Shared road or driveway | Recorder plus road authority | Easement and maintenance agreement | Request unrecorded agreements from seller |
| Planned utility obligation | Utility and capital plan | Main extension, assessment, connection schedule | Separate approved work from conceptual planning |
| HOA or condo existence | Recorded declaration, corporate registry, association | Entity, declaration, amendments | Current financial documents usually require owner request |
| Municipal service and special district | Local government and tax bill | Trash, fire, lighting, stormwater, community charges | Boundaries can differ from postal geography |
| Address and emergency access | Addressing or 911 authority | Official situs and unit designation | Resolve discrepancies before marketing |

## 7. Records that usually require the owner or a professional

Place unavailable items in `unavailable-and-follow-up.md` with the responsible party and requested action:

- Current survey, staking, or boundary opinion
- Full title search and title-insurance exceptions
- Seller's property disclosure and repair invoices
- Well-water laboratory testing and current flow testing
- Septic pumping, inspection, and private maintenance history
- Insurance claim or loss-history report
- Current insurance availability and quotations
- HOA or condo resale package, budget, reserves, insurance, minutes, violations, litigation, and special assessments
- Solar lease, financing, payoff, and transfer documents
- Private-road, shared-well, shared-septic, or maintenance agreements not recorded publicly
- Structural, geotechnical, environmental, mold, radon, lead, asbestos, or other professional testing
- Written zoning verification, rebuildability, or legal-nonconforming determination
- Agency-certified permit history when the public portal is incomplete
