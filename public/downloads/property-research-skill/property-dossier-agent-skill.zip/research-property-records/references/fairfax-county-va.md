# Fairfax County, Virginia record retrieval

Use this route for Fairfax County properties after confirming the parcel and tax-map number. County systems divide useful records among Land Development Services, Planning and Development, the Circuit Court, and the Health Department.

## Retrieve public site and grading plans

1. Start with the official Fairfax County Site Records Viewer linked by Land Development Services. Search the exact tax-map parcel number, preserving spaces and leading zeroes, and also try normalized variants.
2. Inspect every returned record and related or revision record. High-value types include RPA plans, rough grading plans, site plans, waivers, subdivision plans, and revisions.
3. Follow the official document link from the feature or record details to the native county PDF. The viewer's ArcGIS feature or JSON response is only an index lead.
4. Search again using each discovered plan, waiver, permit, and project number. Parent records and revisions often expose different attachments.
5. Keep complete native plan sets. Visually inspect every sheet, then make labeled PDF excerpts for signed plats, drainfield or reserve-area depictions, well locations, approval conditions, and other useful sheets.

Do not call an RPA, grading, or site-plan sheet the recorded subdivision plat unless the document itself is the recorded plat. Record the deed book/page or instrument reference and obtain that separately from the Circuit Court land-record system.

## Reconcile the main Fairfax record holders

| Record family | Primary holder or route | Required retrieval target |
|---|---|---|
| Recorded deed, subdivision plat, easement | Fairfax Circuit Court land records/CPAN or courthouse research room | Recorded instrument and every referenced exhibit or plat |
| Building permit and inspections | Land Development Services/PLUS and LDS public-records process | Application, approved architectural/structural plans, amendments, trade permits, inspections, corrections, finals, and CO/RUP when applicable |
| Special permit, variance, zoning case | Planning and Development and public zoning case materials | Application, staff report, decision, conditions, approved plat/site plan, floor plan, and referenced attachments |
| Septic and well | Fairfax County Health Department, Environmental Health | Septic application/design, soil or perc tests, drainfield and reserve-area plan, installation/as-built and repair records; well application, location, completion log, depth, yield, and abandonment records |
| Grading, RPA, site, waiver | Land Development Services Site Records Viewer and related public plan systems | Complete native plan set, revisions, approval letters, waivers, and recorded maintenance exhibits when cited |

## Interpret cross-record evidence carefully

- A grading plan may show an existing drainfield, reserve area, or well. Treat it as a useful location depiction, not the Health Department's design or as-built approval.
- A zoning decision may name a special-permit plat or floor plan without including it in the public packet. List each cited attachment separately and request it from Planning and Development.
- A building permit card may identify a project but omit plans, trade permits, and inspection documents. Reconcile each expected component in the attachment inventory.
- A deed book/page citation identifies the recorded target but is not the recorded image. CPAN access restrictions do not convert the citation into a delivered plat.

## When public access is blocked

Do not bypass county security controls, authentication, subscriptions, or CAPTCHAs. Try the official public Site Records Viewer and official meeting or case-document pages, then record the precise missing file and holder.

Use the official agency public-records process for the remaining file. Before submitting on the user's behalf, obtain explicit authorization and all legally required requester information. The delivery email alone is not authorization. Ask the agency for an estimate or user approval before incurring charges.

## Fairfax completion gate

Before delivery, reconcile at least these categories when a related record number was found:

- Recorded subdivision or boundary plat and cited exhibits
- Zoning decision plus its approved plat, floor plan, and conditions
- Building permit plans, revisions, trade permits, inspections, finals, and occupancy approval
- Septic design, perc/soil work, drainfield and reserve-area layout, installation/as-built, repairs, and approved capacity
- Well application, location, construction/completion log, depth, yield, and abandonment history
- Site, RPA, grading, waiver, and revision plan sets

Deliver retrieved PDFs individually or in a clearly labeled folder. Put only genuinely unavailable items in the follow-up list, naming the exact document and request office.
