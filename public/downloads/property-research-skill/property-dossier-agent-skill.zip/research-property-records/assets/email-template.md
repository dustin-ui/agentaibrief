Subject: Property records report — {{property_address}}

Hello,

The property-record research package for {{property_address}} is complete.

Research completed: {{date_and_timezone}}

Key items:

- Red — action likely required: {{summary_or_none}}
- Yellow — verify: {{summary_or_none}}
- Important unavailable records: {{summary_or_none}}
- Nearby active or scheduled projects: {{summary_or_none}}

Attached are the report, source index, and collected public records. {{If needed: The full package exceeded the email provider's attachment limit, so it is available through the recipient-restricted link below.}}

{{secure_share_link_if_needed}}

This is a time-stamped public-record screening, not a survey, title examination, environmental assessment, engineering or legal opinion, permit certification, or guarantee of completeness. Please follow the report's recommended verification steps for material items.

Best,
{{sender_name_or_team}}
