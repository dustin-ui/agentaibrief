# Property Records Report

**Subject property:** {{full_address}}  
**Parcel/account ID:** {{parcel_id}}  
**Research completed:** {{research_date_and_timezone}}  
**Prepared for delivery to:** {{recipient_email_or_redacted_recipient}}  
**Scope:** Public-record screening; no comparable-sales or valuation analysis

## Executive summary

### Red — action likely required

{{red_findings_or_none}}

### Yellow — verify

{{yellow_findings_or_none}}

### Green — supporting records located

{{green_findings_or_none}}

### Gray — unavailable or outside public scope

{{gray_findings_or_none}}

## Property and jurisdiction identification

| Field | Finding | Source ID |
|---|---|---|
| Normalized address | {{value}} | {{source}} |
| Parcel/account | {{value}} | {{source}} |
| County-equivalent | {{value}} | {{source}} |
| Municipality/township | {{value}} | {{source}} |
| Permit authority | {{value}} | {{source}} |
| Planning/zoning authority | {{value}} | {{source}} |
| Well/septic authority | {{value}} | {{source}} |

## Reconciliation findings

| Feature or fact | Seller/observed | Assessment | Permit/agency | Recorded document | Status and action |
|---|---|---|---|---|---|
| {{item}} | {{value}} | {{value}} | {{value}} | {{value}} | {{status}} |

## Parcel, tax, deed, plat, and recorded interests

{{findings_with_source_ids}}

## Permits, inspections, occupancy, and code enforcement

{{findings_with_source_ids}}

## Well, septic, water, sewer, and utilities

{{findings_with_source_ids}}

## Zoning, land use, licenses, and development rights

{{findings_with_source_ids}}

## Flood, wetlands, soils, drainage, and other hazards

{{findings_with_source_ids}}

## Environmental, historic, agricultural, and conservation records

{{findings_with_source_ids}}

## Access, roads, association, and special obligations

{{findings_with_source_ids}}

## Nearby construction and development

**Search horizon:** {{horizon}}  
**Search area:** {{radii_and_corridors}}  
**Authorities searched:** {{authorities}}

### Active, awarded, scheduled, or permitted

| Project | Distance/direction | Status and date | Published timing | Scope | Potential impact channels | Confidence | Sources |
|---|---|---|---|---|---|---|---|
| {{project}} | {{distance}} | {{status}} | {{timing}} | {{scope}} | {{impacts}} | {{confidence}} | {{sources}} |

### Approved but not yet permitted

{{projects_or_none}}

### Pending and conceptual watchlist

{{projects_or_none}}

## Unavailable records and recommended follow-up

| Missing or unverified item | Why it matters | Record holder/professional | Recommended action |
|---|---|---|---|
| {{item}} | {{reason}} | {{holder}} | {{action}} |

## Attachment completeness

| Parent case or permit | Expected document | Status | Delivered file/source | Missing-record action |
|---|---|---|---|---|
| {{record}} | {{document}} | {{retrieved/not-public/not-located/not-applicable}} | {{file_or_source}} | {{action_or_none}} |

An index entry or case summary does not count as the underlying document. See `attachment-inventory.csv` for the complete reconciliation.

## Methodology and limitations

This report is a time-stamped screening of the public and provided sources listed in `source-index.csv`. "No matching record located" does not mean that no record exists. Online maps and databases can be incomplete, stale, indexed under another identifier, or nonauthoritative at parcel scale.

This report is not a survey, title examination, environmental assessment, engineering opinion, legal opinion, permit certification, insurance determination, or guarantee of completeness. Confirm material matters with the record-holding agency and the appropriate licensed professional.
