#!/usr/bin/env python3
"""Validate and ZIP a completed property-records case folder."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import sys
import zipfile


REPORT_PREFIXES = ("property-records-report", "executive-summary")
REQUIRED_EXACT = (
    "source-index.csv",
    "attachment-inventory.csv",
    "unavailable-and-follow-up.md",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_files(case_dir: Path, output: Path) -> list[Path]:
    files: list[Path] = []
    for path in sorted(case_dir.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"Symlinks are not allowed in a delivery package: {path}")
        if not path.is_file():
            continue
        if path.resolve() == output.resolve() or path.name == "manifest.json":
            continue
        files.append(path)
    return files


def validate_minimum(case_dir: Path, files: list[Path]) -> list[str]:
    relative_names = {path.relative_to(case_dir).as_posix() for path in files}
    root_names = {path.name for path in files if path.parent == case_dir}
    errors: list[str] = []

    for required in REQUIRED_EXACT:
        if required not in root_names:
            errors.append(f"Missing required root file: {required}")

    has_report = any(
        any(name.startswith(prefix + ".") for prefix in REPORT_PREFIXES)
        for name in root_names
    )
    if not has_report:
        errors.append(
            "Missing report: add property-records-report.* or executive-summary.* at the case root"
        )

    if not any(name.startswith("records/") for name in relative_names):
        errors.append("The records/ directory contains no files")

    return errors


def write_manifest(case_dir: Path, files: list[Path]) -> Path:
    manifest_path = case_dir / "manifest.json"
    payload = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "case_folder": case_dir.name,
        "files": [
            {
                "path": path.relative_to(case_dir).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in files
        ],
    }
    manifest_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return manifest_path


def build_zip(case_dir: Path, output: Path, files: list[Path], manifest: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in [*files, manifest]:
            archive.write(path, arcname=f"{case_dir.name}/{path.relative_to(case_dir).as_posix()}")

    with zipfile.ZipFile(output, "r") as archive:
        bad_member = archive.testzip()
    if bad_member:
        raise RuntimeError(f"ZIP integrity check failed at: {bad_member}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case_dir", type=Path, help="Completed property-records case folder")
    parser.add_argument(
        "--output",
        type=Path,
        help="ZIP output path; defaults beside the case folder",
    )
    parser.add_argument(
        "--allow-incomplete",
        action="store_true",
        help="Package despite missing minimum deliverables; intended only for script testing",
    )
    args = parser.parse_args()

    case_dir = args.case_dir.expanduser().resolve()
    if not case_dir.is_dir():
        parser.error(f"Case directory does not exist: {case_dir}")

    output = (
        args.output.expanduser().resolve()
        if args.output
        else case_dir.with_name(case_dir.name + ".zip")
    )

    try:
        files = collect_files(case_dir, output)
        if not files:
            raise ValueError("Case directory contains no files")

        errors = validate_minimum(case_dir, files)
        if errors and not args.allow_incomplete:
            for error in errors:
                print(f"ERROR: {error}", file=sys.stderr)
            return 2

        for warning in errors:
            print(f"WARNING: {warning}", file=sys.stderr)

        manifest = write_manifest(case_dir, files)
        build_zip(case_dir, output, files, manifest)
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(f"Created: {output}")
    print(f"Files: {len(files) + 1}")
    print(f"SHA256: {sha256(output)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
