---
name: research-property-records
description: Research and package non-comparable property due-diligence records for a residential or land address, including parcel and tax data, deeds and plats, permits and code cases, well and septic records, zoning, hazards, environmental and historic restrictions, utilities, access, associations, and nearby planned or active construction. Use when a seller, buyer, or real-estate professional asks for a pre-listing property-record scan, permit or plat research, a property dossier, or a source-linked public-record package that requires discovering the correct jurisdictions from the address and emailing the completed records.
---

# Research Property Records

Create an evidence-linked property-record dossier. Find discrepancies and upcoming external changes that could surprise a seller or buyer; do not estimate value or perform comparable-sales analysis unless separately requested.

## Collect the required inputs

Require:

- The complete property address, including country when outside the United States.
- The email address that should receive the final report and collected records.

If either is missing, ask one concise question: "What is the complete property address, and what email address should receive the finished report and records?"

Do not ask again when both are already present in the request or trusted conversation context. Confirm an ambiguous property match before continuing. Use the email address only for delivery and access sharing.

## Follow the workflow

### 1. Establish the property and governing jurisdictions

1. Normalize the address without silently changing the property.
2. Resolve the country, state or province, county-equivalent, incorporated municipality or township, postal locality, and any relevant special district.
3. Verify the match against an official parcel, assessor, land-registry, or address source. Near a boundary, corroborate the jurisdiction with a second official source.
4. Capture the parcel or account identifier, legal lot identifiers, subdivision, current deed reference, and address variants when available.
5. Determine which authority actually controls each record type. A county may assess property while a city issues permits and a health district holds septic files.

Never infer the responsible agency from the mailing city alone.

### 2. Discover authoritative portals

Build a short authority map covering assessor or cadastre, recorder or land registry, permits and inspections, code enforcement, planning and zoning, environmental health, utilities, roads, state or provincial agencies, and relevant federal or national sources.

Prefer, in order:

1. Official agency pages and databases.
2. Vendor portals linked from an official agency page.
3. Official meeting packets, maps, notices, and downloadable records.
4. Reputable secondary sources only to discover an official record or identify a lead.

Do not treat search snippets, listing portals, crowdsourced maps, or data aggregators as final evidence. Do not bypass authentication, CAPTCHAs, paywalls, or access restrictions. Record the agency, portal, and request path when a record is not publicly accessible.

### 2A. Retrieve the underlying documents, not only index records

Treat a portal result, case summary, permit card, GIS feature, JSON response, or metadata page only as a lead. It is not a copy of the underlying record. Open every relevant documents, attachments, plans, inspections, or related-records area and download the actual files when public access permits.

For each identified case, permit, approval, deed reference, health record, or plat reference, retrieve every material underlying document that is available, including:

- Recorded subdivision plats, boundary or easement plats, deed exhibits, and later revisions.
- Zoning or land-use applications, staff reports, decision letters, conditions, approved plats or site plans, and referenced exhibits.
- Building permit applications, approved architectural or structural plan sets, revisions, trade permits, inspection histories, correction notices, final inspections, and certificates of occupancy or completion.
- Septic applications, soil or percolation tests, approved system designs, drainfield and reserve-area plats, installation or as-built records, repair records, operating permits, and abandonment records.
- Well applications, construction or completion logs, location plats, yield or depth records, treatment records when public, and abandonment records.

Do not describe an index entry as a plat, plan, permit file, septic field record, inspection record, or other document copy. If an underlying document cannot be downloaded, mark that specific document **unavailable** and record the exact holder, portal or request form, authentication or authorization requirement, and recommended next action. A case is not complete merely because its case number and status were located.

Apply these evidence rules:

- A GIS parcel outline is not a recorded plat or survey.
- A permit summary is not the approved plans, inspection history, or final approval.
- A site or grading sheet that labels a drainfield or well proves only what that plan depicts. It is not a substitute for the health department's septic design, reserve-area approval, installation/as-built record, or well completion log.
- A zoning staff report that cites a plat or floor plan is not the cited attachment. Retrieve the attachment separately.
- A generated PDF containing JSON, HTML, a source index, or screenshots of metadata is not the underlying record.

When a large official plan set contains a high-value sheet, retain the complete native plan set and also create a clearly named PDF excerpt for agents. Examples include a signed plat sheet, a drainfield/reserve-area sheet, a well-location sheet, conditions of approval, or a final inspection. Label excerpts as excerpts and cite the full source document.

For Fairfax County, Virginia properties, read [references/fairfax-county-va.md](references/fairfax-county-va.md) completely before searching permits, plans, plats, wells, or septic records.

### 3. Research the core record categories

Read [references/research-matrix.md](references/research-matrix.md) completely before broad research. Search with the address and its variants, parcel number, owner name when legitimately required, subdivision and lot, deed reference, and permit numbers.

For every category:

- Save the original record or a faithful capture when permitted.
- Inventory the expected attachment set for each located case and reconcile it against the files actually downloaded.
- Preserve native agency PDFs and images. Convert non-PDF public records to readable PDF attachments for delivery while retaining the original source file in the full archive.
- Track each expected underlying document as `retrieved`, `not publicly downloadable`, `not located`, or `not applicable`. Do not use the parent case's status as the attachment status.
- Record the direct source URL, agency, record date, retrieval date, search terms or identifiers, and local filename.
- Distinguish "no matching record located" from "no record exists."
- Note coverage gaps, stale data, indexing limitations, and records requiring a formal request.
- Avoid collecting unrelated personal information about owners or neighbors.

### 4. Investigate nearby construction and development

Read [references/nearby-projects.md](references/nearby-projects.md) completely before screening planned work.

Search official active-project maps, development-review portals, planning commission and council packets, rezoning and subdivision cases, permit systems, capital-improvement plans, transportation programs, public-works updates, utility projects, and procurement or construction notices.

Classify every identified project as one of:

- Under construction
- Contract awarded, funded, or officially scheduled
- Permit issued or site work authorized
- Approved but not yet permitted
- Pending public review
- Conceptual or long-range only
- Completed or cancelled

Call a project "happening soon" only when an official schedule, funding action, awarded contract, issued permit, or active construction supports that wording. Put pending and conceptual projects in a watchlist.

State distance, direction, latest official status date, expected timing when published, and plausible impact channels such as traffic, access, noise, dust, drainage, views, utilities, school capacity, or construction detours. Label impact statements as inferences unless an official study makes the claim. Do not predict property-value effects.

### 5. Reconcile the evidence

Compare:

- What physically appears to exist
- What the seller reports
- What the assessor or cadastre reports
- What permits and occupancy records authorize
- What the deed, plat, and recorded agreements describe

Prioritize discrepancies involving bedroom count, finished area, additions, accessory units, pools, decks, septic capacity, well or drainfield location, access, boundaries, easements, open permits, violations, solar obligations, flood status, and association obligations.

Use these finding labels:

- **Red — action likely required:** A documented conflict, open case, unresolved approval, or material restriction.
- **Yellow — verify:** Missing, inconsistent, old, or ambiguous evidence.
- **Green — supporting record located:** Evidence supports the stated fact; do not call the property "clear."
- **Gray — unavailable or outside public scope:** Identify the holder and next action.

### 6. Build the delivery package

Use [assets/property-report-template.md](assets/property-report-template.md) as the report structure, [assets/source-index-template.csv](assets/source-index-template.csv) as the evidence index, and [assets/attachment-inventory-template.csv](assets/attachment-inventory-template.csv) as the underlying-document checklist. Create a case folder containing:

```text
property-records-<property-slug>-<YYYY-MM-DD>/
├── executive-summary.pdf or executive-summary.md
├── property-records-report.pdf or property-records-report.md
├── source-index.csv
├── attachment-inventory.csv
├── unavailable-and-follow-up.md
├── records/
│   ├── parcel-and-land/
│   ├── permits-and-code/
│   ├── well-and-septic/
│   ├── zoning-and-planning/
│   ├── hazards-and-environment/
│   ├── nearby-projects/
│   └── other/
└── manifest.json
```

Preserve useful filenames and prepend a source ID when needed. Do not include credentials, session data, or unnecessary personal data. Use `scripts/package_records.py` to generate `manifest.json`, verify the minimum package, and create the ZIP archive.

Build `attachment-inventory.csv` with one row per expected underlying document, including the parent case or permit, document type, document status, source ID, local PDF path when retrieved, record holder, and next action when missing. This is the completeness checklist; `source-index.csv` remains the source log.

Create an agent-friendly delivery set in addition to the full archive. Attach or share the report, the most decision-useful native PDFs, and any clearly labeled excerpts individually so a recipient does not need to open JSON or unpack the archive to see the records. Keep access restricted to the supplied recipient when the storage provider supports it.

### 7. Perform final quality control

Before delivery, confirm that:

- The address, parcel, and jurisdictions all refer to the same property.
- Both county-equivalent and municipal sources were searched where authority overlaps.
- Each core category is covered or explicitly marked unavailable.
- Nearby projects were searched across every relevant planning and infrastructure authority.
- Project statuses and dates are current and not overstated.
- Every material finding links to evidence.
- Every located permit, land-use case, plat reference, septic record, and well record has its underlying documents attached, or each missing document is individually identified with its exact retrieval or request path.
- The package includes actual readable copies of plats, approved plans, health-system layouts, inspection results, and final approvals when available—not merely portal summaries, JSON exports, or source-index entries.
- Every file presented as a PDF begins with a valid PDF signature, opens successfully, renders legibly, and contains the represented record rather than JSON, HTML, an error page, or a login screen.
- Large plan sets have been visually reviewed sheet by sheet at readable resolution; useful sheets are also delivered as labeled excerpts without replacing the complete plan set.
- `attachment-inventory.csv` reconciles every located case or permit against its expected documents, and every missing item appears in `unavailable-and-follow-up.md`.
- Downloaded files open and the ZIP passes the packaging script.
- The report states its scope, retrieval date, and professional-verification limits.
- The delivery email exactly matches the user-provided address.

### 8. Email the completed records

Use the connected email capability and follow its governing instructions. Treat a request to run this skill as authorization to send the completed package to the supplied delivery address after quality control.

Use this default subject:

`Property records report — <property address>`

Use [assets/email-template.md](assets/email-template.md) for the body. Include a concise Red/Yellow summary, the research date, important unavailable records, and the limitations statement. Attach the report, source index, and ZIP when the provider permits. When the package exceeds the provider's attachment limit, upload it through an available connected storage service, restrict access to the delivery recipient when possible, and email the share link. Never expose a broadly public link without warning.

If no connected email capability is available, provide the downloadable package in the conversation, state clearly that it was not emailed, and ask the user to connect or authorize an email service. Never claim delivery without a successful send result.

After a successful send, report the recipient, subject, delivery time, and message identifier when available.

### 9. Handle formal record requests separately

Do not treat the delivery email as authorization to submit a freedom-of-information, public-records, title-copy, or health-record request. Such requests can disclose the user's identity, require residency or contact information, create fees, or make legally significant representations.

Before submitting one on the user's behalf, identify the exact missing documents and request office, disclose any known fee or identity requirement, and obtain the user's explicit authorization plus the required legal name, address, phone, residency confirmation, and fee limit. If authorization is not provided, prepare the exact request language and contact path without submitting it.

## Apply professional limits

Describe this work as a public-record screening, not a survey, title examination, environmental assessment, engineering opinion, legal opinion, permit certification, or guarantee of completeness. Refer boundary issues to a licensed surveyor, title and encumbrance questions to the appropriate title or legal professional, condition questions to inspectors or engineers, and regulatory interpretations to the responsible agency.

Share neighborhood or demographic information only when requested and do so consistently, neutrally, and in compliance with applicable fair-housing law, local law, and brokerage policy.
