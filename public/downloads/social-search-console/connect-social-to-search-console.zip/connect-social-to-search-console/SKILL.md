---
name: connect-social-to-search-console
description: Guide a creator, business, or agency step by step through adding Instagram, TikTok, X, and YouTube accounts as Google Search Console Platform Properties. Use when someone wants to connect, verify, reconnect, troubleshoot, or understand social and video properties in Search Console, including what the reports measure and what to do when the feature or data is unavailable.
---

# Connect Social to Search Console

Help the user connect every supported social profile or channel they control to Google Search Console. Work interactively, one account at a time, and keep a visible progress checklist.

## Ground rules

- Treat each Instagram profile, TikTok account, X account, or YouTube channel as a separate Platform Property.
- Never ask for a password, recovery code, two-factor code, API token, or exported session. Tell the user to enter credentials only on the platform's own authorization screen.
- Do not claim that adding a property improves rankings or indexing. It enables reporting.
- Explain that reports cover performance on Google surfaces, not native-platform reach, views, likes, comments, shares, watch time, or followers.
- Expect reports to take several days to populate. Discover and Google News reports appear only after eligible traffic exists.
- Say clearly when a requested platform is unsupported. As of July 2026, the supported platforms are Instagram, TikTok, X, and YouTube.
- Because this feature is rolling out gradually, do not treat a missing Platform Property option as user error.
- If live browsing is available and the interface differs, consult the official links in `references/official-guide.md` before advising.

## Workflow

### 1. Inventory the accounts

Ask the user to list the profiles or channels they control. For each one, capture:

- Platform
- Public handle or channel name
- Whether the user can sign in as an owner or administrator
- Whether it is already connected

Create a compact checklist, for example:

```text
[ ] Instagram — @brand
[ ] TikTok — @brand
[ ] X — @brand
[ ] YouTube — Brand Channel
```

If the user lists several accounts on one platform, keep them as separate checklist items. Do not ask them to paste passwords or private credentials.

### 2. Run the preflight

Confirm that the user:

1. Is signed in to the intended Google account.
2. Can open [Google Search Console](https://search.google.com/search-console/).
3. Can sign in to the target social account or channel with owner/admin rights.
4. Can identify the correct handle or channel if the authorization screen shows multiple choices.

If using a shared or agency-managed Google account, recommend deciding which Google account should retain long-term ownership before connecting profiles.

### 3. Connect one property

Guide the user through these steps:

1. Open Search Console.
2. Open the property selector in the upper-left area.
3. Choose **+ Add property**.
4. In the Platform Property area, choose **Add** beside Instagram, TikTok, X, or YouTube.
5. Follow the on-screen authorization flow.
6. On the platform's own sign-in/consent screen, select the intended account and approve the requested connection.
7. Return to Search Console and wait for ownership confirmation.
8. Choose **Go to property**.
9. Confirm that the property appears in the property selector with the expected handle or channel.

Ask the user to report what they see after each major screen. If image understanding is available, invite a screenshot with sensitive information hidden. Do not invent button labels beyond what the current screen shows.

### 4. Verify and record success

Mark an account complete only after the property appears in the property selector. Record one of these states:

- Connected
- Already connected
- Waiting for access
- Feature not available yet
- Authorization failed
- Wrong account selected

Then move to the next checklist item and repeat the connection flow.

### 5. Orient the user to reports

After at least one property is connected, briefly explain:

- **Performance:** clicks, impressions, click-through rate, average position, posts/pages, and search queries from Google surfaces.
- **Insights:** a simplified view of recent trends, top content, and discovery patterns.
- **Achievements:** click-based growth milestones.
- **Discover and Google News:** shown only when the property receives qualifying traffic from those surfaces.
- **Initial delay:** empty charts or partial data are normal for several days after setup.

Offer a simple first review after data appears: set the date range to 28 days, inspect top queries and top content, and note high-impression/low-CTR opportunities.

### 6. Finish with a handoff

Return the completed checklist, unresolved items, and the exact next action for each unresolved item. Remind the user that Google periodically rechecks ownership; expired platform authorization can pause access until the account is reauthenticated, after which the same reports become available again.

## Troubleshooting

Use `references/troubleshooting.md` when a platform option is missing, authorization loops, the wrong profile is selected, access is paused, or reports are empty.

## Boundaries

- Do not add a social profile as a URL-prefix property. Use Platform Property.
- Do not advise DNS, HTML-file, or meta-tag verification for a social profile. Those methods apply to website properties.
- Do not promise coverage for Facebook, LinkedIn, Pinterest, Threads, Bluesky, Snapchat, or any other unsupported platform.
- Do not treat a platform connection as a substitute for adding and verifying the user's own website property.
- Do not include unrelated video-schema, sitemap, crawl-limit, or website-indexing work unless the user separately asks to optimize a website hosting videos.
