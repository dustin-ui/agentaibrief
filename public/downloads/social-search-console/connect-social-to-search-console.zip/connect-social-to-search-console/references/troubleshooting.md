# Platform Property troubleshooting

## Platform option is missing

First determine whether the entire Platform Property area is absent or whether only one platform is missing.

If the entire area is absent:

1. Confirm the user opened **+ Add property**, not the website URL-prefix form alone.
2. Confirm they are signed in to the intended Google account.
3. Refresh Search Console or try a private browser window with only the intended Google account signed in.
4. Check the official rollout notice. The feature is gradual and may not be available to every account yet.
5. If still absent, record **Feature not available yet** and suggest trying again later or sending feedback from Search Console.

If some supported platforms appear but one is missing:

1. Recheck the full list and scroll the dialog if possible.
2. Refresh or retry in a private window with only the intended Google account signed in.
3. Consult the current official help page to confirm that the platform is still supported.
4. If it remains missing, preserve a screenshot of the available choices and submit feedback from Search Console.

Never use a social URL as a workaround website property.

## Authorization fails or loops

1. Confirm the browser allows pop-ups and cross-site sign-in for this attempt.
2. Sign out of unrelated social accounts or use a private window.
3. Start again from Search Console and select the intended profile carefully.
4. Confirm the user has owner/admin rights rather than viewer or analyst access.
5. If the provider shows an error, preserve its exact wording and use the provider's recovery flow. Never ask the user to share credentials or two-factor codes.

## Wrong account or channel was connected

1. Verify the handle or channel shown in the Search Console property selector.
2. If it is wrong, remove or disconnect only that incorrect property through the available Search Console settings.
3. Repeat the add-property flow in a private window or after signing out of other platform accounts.
4. Verify the new property before marking it connected.

## Access is paused or ownership must be checked again

Google periodically rechecks ownership. A platform password change, expired login, revoked permission, or account-role change can break authorization. Follow the reauthentication prompt in Search Console, sign in on the platform's official page, and verify that the same property and reports return.

## Property is connected but reports are empty

1. Allow several days for initial processing.
2. Widen the reporting date range.
3. Confirm the property matches the intended public account or channel.
4. Remember that Search Console reports only visibility and interactions on Google surfaces; native-platform activity does not populate these reports.
5. Discover and Google News tabs appear only after qualifying traffic exists.
6. If the property remains empty after a reasonable wait, compare the behavior with the current official help page and submit feedback in Search Console.

## A requested platform is unsupported

Explain that Platform Properties currently support Instagram, TikTok, X, and YouTube. Offer to connect the supported accounts now and place the unsupported account on a watchlist. Do not promise a release date or fabricate an alternate verification method.
