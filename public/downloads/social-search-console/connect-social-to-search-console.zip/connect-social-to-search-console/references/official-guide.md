# Official Google references

Consult these pages when the interface, supported platforms, rollout status, reporting behavior, or verification flow may have changed.

Last verified against official Google documentation: July 29, 2026. At that time, Google's Help Center still described availability as a gradual rollout.

- [About platform properties in Search Console](https://support.google.com/webmasters/answer/17148418?hl=en)
- [Add a website or platform property to Search Console](https://support.google.com/webmasters/answer/34592?hl=en-NA)
- [Google Search Central launch announcement: See how content from social and video platforms performs on Google Search](https://developers.google.com/search/blog/2026/07/search-console-social-video-platforms)
- [Open Google Search Console](https://search.google.com/search-console/)

Prefer these official sources over third-party setup guides. If the official pages conflict with this skill, follow the official pages and tell the user that the product has changed.
